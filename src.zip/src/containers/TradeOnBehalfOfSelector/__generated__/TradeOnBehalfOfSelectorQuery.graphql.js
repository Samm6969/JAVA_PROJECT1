/**
 * @flow
 * @relayHash 5c50db0a7f9268546ceeaac3588cded9
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type TradeOnBehalfOfSelectorQueryVariables = {||};
export type TradeOnBehalfOfSelectorQueryResponse = {|
  +viewer: ?{|
    +institutionLocations: ?$ReadOnlyArray<?{|
      +id: string,
      +self: ?boolean,
      +location: ?{|
        +name: ?string
      |},
      +institution: ?{|
        +name: ?string
      |},
    |}>
  |}
|};
export type TradeOnBehalfOfSelectorQuery = {|
  variables: TradeOnBehalfOfSelectorQueryVariables,
  response: TradeOnBehalfOfSelectorQueryResponse,
|};
*/


/*
query TradeOnBehalfOfSelectorQuery {
  viewer {
    institutionLocations {
      id
      self
      location {
        name
        id
      }
      institution {
        name
        id
      }
    }
    id
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v1 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "self",
  "args": null,
  "storageKey": null
},
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "name",
  "args": null,
  "storageKey": null
},
v3 = [
  v2
],
v4 = [
  v2,
  v0
];
return {
  "kind": "Request",
  "operationKind": "query",
  "name": "TradeOnBehalfOfSelectorQuery",
  "id": null,
  "text": "query TradeOnBehalfOfSelectorQuery {\n  viewer {\n    institutionLocations {\n      id\n      self\n      location {\n        name\n        id\n      }\n      institution {\n        name\n        id\n      }\n    }\n    id\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "TradeOnBehalfOfSelectorQuery",
    "type": "Root",
    "metadata": null,
    "argumentDefinitions": [],
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "institutionLocations",
            "storageKey": null,
            "args": null,
            "concreteType": "InstitutionLocation",
            "plural": true,
            "selections": [
              v0,
              v1,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "location",
                "storageKey": null,
                "args": null,
                "concreteType": "Location",
                "plural": false,
                "selections": v3
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "institution",
                "storageKey": null,
                "args": null,
                "concreteType": "Institution",
                "plural": false,
                "selections": v3
              }
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "TradeOnBehalfOfSelectorQuery",
    "argumentDefinitions": [],
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "institutionLocations",
            "storageKey": null,
            "args": null,
            "concreteType": "InstitutionLocation",
            "plural": true,
            "selections": [
              v0,
              v1,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "location",
                "storageKey": null,
                "args": null,
                "concreteType": "Location",
                "plural": false,
                "selections": v4
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "institution",
                "storageKey": null,
                "args": null,
                "concreteType": "Institution",
                "plural": false,
                "selections": v4
              }
            ]
          },
          v0
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = '436708734efc734c67bf92c881b61e83';
module.exports = node;
