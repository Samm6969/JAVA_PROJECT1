import cx from 'classnames'
import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { FieldArray } from 'redux-form'
import { Icon, Tooltip, List } from '@fc/react-playbook'

import MMFOrderEntryFormAccountList from './MMFOrderEntryFormAccountList'

import s from './MMFOrderEntryFormFundGroup.scss'
import MMFOrderEntryFormValueField from './MMFOrderEntryFormValueField'

class MMFOrderEntryFormFundGroup extends Component {
  static propTypes = {
    fields: PropTypes.shape({
      map: PropTypes.func,
    }),
  }

  render() {
    const { fields } = this.props
    return fields.map((member, index) => {
      const { fund } = fields.get(index)
      const {
        cusip,
        isin,
        provider,
        iso,
        subscriptionGate,
        redemptionGate,
        redemptionFeeInEffect,
        currency,
        name,
      } = fund

      const gateMessages = (
        <List noStyle>
          {redemptionGate && <li>Redemption Gate In Effect</li>}
          {subscriptionGate && <li>Purchase Gate In Effect</li>}
        </List>
      )

      return (
        <div key={member} className={s.fundGroup}>
          <div className={s.fundInfo}>
            <div className={s.fundName}>{`${name} (${provider.name})`}</div>
            <div className={s.fundDetails}>
              <MMFOrderEntryFormValueField
                label="Currency"
                value={currency.currencyCode}
              />
              {iso && (
                <MMFOrderEntryFormValueField label="Fund Number" value={iso} />
              )}
              {cusip && (
                <MMFOrderEntryFormValueField label="CUSIP" value={cusip} />
              )}
              {isin && (
                <MMFOrderEntryFormValueField label="ISIN" value={isin} />
              )}
              {redemptionFeeInEffect && (
                <Tooltip content="Redemption Liquidity Fee In Effect">
                  <Icon name="material-warning" className={cx(s.warning)} />
                </Tooltip>
              )}
              {(subscriptionGate || redemptionGate) && (
                <Tooltip content={gateMessages}>
                  <Icon name="material-error" className={cx(s.error)} />
                </Tooltip>
              )}
            </div>
          </div>
          <FieldArray
            name={`${member}.accounts`}
            component={MMFOrderEntryFormAccountList}
          />
        </div>
      )
    })
  }
}

export default MMFOrderEntryFormFundGroup
