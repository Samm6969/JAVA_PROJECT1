/**
 * @flow
 * @relayHash 5abef91f8a68a68fcd3c351019b808b1
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type AutoSettlementModelEnum = "PLATFORM" | "REGISTERED" | "%future added value";
export type OrderQtyTypeEnum = "CURRENCY" | "SHARES" | "%future added value";
export type OrderSideEnum = "BUY" | "CREATE" | "DIVIDEND_CASH" | "DIVIDEND_NOT_SUPPORTED" | "DIVIDEND_OTHER" | "DIVIDEND_REDUCTION" | "DIVIDEND_REINVEST" | "REDEEM" | "SELL" | "UNKNOWN" | "%future added value";
export type RedemptionFeeTypeEnum = "GROSS" | "NET" | "%future added value";
export type TradeValidationErrorLevelEnum = "ERROR" | "RESTRICTED" | "WARNING" | "%future added value";
export type OrderRequestsInput = {
  clientMutationId?: ?string,
  orderRequests?: ?$ReadOnlyArray<?OrderRequestInput>,
};
export type OrderRequestInput = {
  fundAccountId: string,
  side?: ?OrderSideEnum,
  qtyType?: ?OrderQtyTypeEnum,
  quantity?: ?number,
  tradeDate?: ?string,
  redemptionFeeType?: ?RedemptionFeeTypeEnum,
  overriddenSettlementPeriod?: ?number,
  userTradeWindowId?: ?number,
  investorCashSettlementInstruction?: ?number,
  investorCustodySettlementInstruction?: ?number,
  investorPaymentInstruction?: ?number,
  comments?: ?string,
  approvalMessage?: ?string,
};
export type MMFOrderEntryFormMutationVariables = {|
  input: OrderRequestsInput
|};
export type MMFOrderEntryFormMutationResponse = {|
  +enterOrders: ?{|
    +id: string,
    +orderResponsesId: ?string,
    +tradeValidationSummaryMessages: ?$ReadOnlyArray<?string>,
    +orderResponses: ?$ReadOnlyArray<?{|
      +id: string,
      +orderResponseId: ?string,
      +orderRequest: ?{|
        +id: string,
        +fundAccountId: ?string,
        +side: ?OrderSideEnum,
        +qtyType: ?OrderQtyTypeEnum,
        +quantity: ?number,
        +tradeDate: ?string,
        +redemptionFeeType: ?RedemptionFeeTypeEnum,
        +overriddenSettlementPeriod: ?number,
        +userTradeWindowId: ?number,
        +investorCashSettlementInstruction: ?number,
        +investorCustodySettlementInstruction: ?number,
        +investorPaymentInstruction: ?number,
        +comments: ?string,
        +approvalMessage: ?string,
      |},
      +fundAccount: ?{|
        +account: ?{|
          +name: ?string,
          +autoPopulateDefaultSsi: ?boolean,
        |},
        +balance: ?{|
          +balanceDt: ?string,
          +shares: ?number,
          +balanceAmt: ?number,
          +balanceAmtUSDE: ?number,
          +estimatedMarketValue: ?number,
          +estimatedMarketValueUSDE: ?number,
          +accruedAmt: ?number,
          +currencyCode: ?string,
          +value: ?number,
          +percentageOwned: ?number,
          +stale: ?boolean,
          +fxRateDTO: ?{|
            +usdMid: ?number,
            +stale: ?boolean,
            +effectiveDate: ?string,
          |},
        |},
        +fund: ?{|
          +redemptionGate: ?boolean,
          +subscriptionGate: ?boolean,
          +redemptionFeeInEffect: ?boolean,
          +fundRoutingAutoSettlementSupported: ?boolean,
          +providerSettlementInstructionAssociated: ?boolean,
          +autoSettlementModel: ?AutoSettlementModelEnum,
          +defaultPrice: ?string,
          +stableNav: ?boolean,
          +redemptionFeeType: ?RedemptionFeeTypeEnum,
          +redemptionFeePct: ?number,
          +id: string,
          +fundId: ?string,
          +supportTradeWindows: ?boolean,
          +fundType: ?string,
          +provider: ?{|
            +name: ?string
          |},
          +name: ?string,
          +longName: ?string,
          +fundCategory: ?{|
            +name: ?string
          |},
          +fundSubCategory: ?{|
            +name: ?string
          |},
          +currency: ?{|
            +currencyCode: ?string
          |},
          +domicileCountry: ?{|
            +name: ?string
          |},
          +settlementPeriod: ?number,
          +overrideSettlementDate: ?boolean,
          +supportedRedemptionFeeTypes: ?$ReadOnlyArray<?RedemptionFeeTypeEnum>,
          +subCutoffTime: ?string,
          +subCutoffTimeType: ?string,
          +redCutoffTime: ?string,
          +redCutoffTimeType: ?string,
        |},
        +supportedQtyTypes: ?{|
          +buy: ?$ReadOnlyArray<?string>,
          +sell: ?$ReadOnlyArray<?string>,
        |},
        +cashInstructions: ?$ReadOnlyArray<?{|
          +id: string,
          +displayName: ?string,
          +custodianName: ?string,
          +custodianAccount: ?string,
          +custodianBIC: ?string,
          +cashCutoffTimeDisplay: ?string,
          +cashInstructionId: ?string,
          +defaultCurrencySSI: ?boolean,
        |}>,
        +custodyInstructions: ?$ReadOnlyArray<?{|
          +displayName: ?string,
          +custodianName: ?string,
          +custodianAccount: ?string,
          +custodianBIC: ?string,
          +custodyInstructionId: ?string,
          +defaultCurrencySSI: ?boolean,
        |}>,
        +tradeWindows: ?$ReadOnlyArray<?{|
          +startTime: ?string,
          +endTime: ?string,
          +fundTimezoneName: ?string,
          +tradeWindowsId: ?number,
          +providerTradeWindowRef: ?string,
          +expectedPriceTime: ?string,
          +redEndTime: ?string,
          +subEndTime: ?string,
          +subscriptionSettlementPeriod: ?number,
          +redemptionSettlementPeriod: ?number,
        |}>,
      |},
      +tradeInputValidationErrors: ?$ReadOnlyArray<?{|
        +errorCode: ?string,
        +errorText: ?string,
      |}>,
      +tradeBusinessRulesValidationErrors: ?$ReadOnlyArray<?{|
        +errorCode: ?string,
        +errorMessage: ?string,
        +errorLevel: ?TradeValidationErrorLevelEnum,
      |}>,
      +tradeComplianceRulesValidationErrors: ?$ReadOnlyArray<?{|
        +errorCode: ?string,
        +errorMessage: ?string,
        +errorLevel: ?TradeValidationErrorLevelEnum,
      |}>,
    |}>,
  |}
|};
export type MMFOrderEntryFormMutation = {|
  variables: MMFOrderEntryFormMutationVariables,
  response: MMFOrderEntryFormMutationResponse,
|};
*/


/*
mutation MMFOrderEntryFormMutation(
  $input: OrderRequestsInput!
) {
  enterOrders(input: $input) {
    id
    orderResponsesId
    tradeValidationSummaryMessages
    orderResponses {
      id
      orderResponseId
      orderRequest {
        id
        fundAccountId
        side
        qtyType
        quantity
        tradeDate
        redemptionFeeType
        overriddenSettlementPeriod
        userTradeWindowId
        investorCashSettlementInstruction
        investorCustodySettlementInstruction
        investorPaymentInstruction
        comments
        approvalMessage
      }
      fundAccount {
        account {
          name
          autoPopulateDefaultSsi
          id
        }
        balance {
          balanceDt
          shares
          balanceAmt
          balanceAmtUSDE
          estimatedMarketValue
          estimatedMarketValueUSDE
          accruedAmt
          currencyCode
          value
          percentageOwned
          stale
          fxRateDTO {
            usdMid
            stale
            effectiveDate
          }
        }
        fund {
          redemptionGate
          subscriptionGate
          redemptionFeeInEffect
          fundRoutingAutoSettlementSupported
          providerSettlementInstructionAssociated
          autoSettlementModel
          defaultPrice
          stableNav
          redemptionFeeType
          redemptionFeePct
          id
          fundId
          supportTradeWindows
          fundType
          provider {
            name
            id
          }
          name
          longName
          fundCategory {
            name
            id
          }
          fundSubCategory {
            name
            id
          }
          currency {
            currencyCode
            id
          }
          domicileCountry {
            name
            id
          }
          settlementPeriod
          overrideSettlementDate
          supportedRedemptionFeeTypes
          subCutoffTime
          subCutoffTimeType
          redCutoffTime
          redCutoffTimeType
        }
        supportedQtyTypes {
          buy
          sell
          id
        }
        cashInstructions {
          id
          displayName
          custodianName
          custodianAccount
          custodianBIC
          cashCutoffTimeDisplay
          cashInstructionId
          defaultCurrencySSI
        }
        custodyInstructions {
          displayName
          custodianName
          custodianAccount
          custodianBIC
          custodyInstructionId
          defaultCurrencySSI
          id
        }
        tradeWindows {
          startTime
          endTime
          fundTimezoneName
          tradeWindowsId
          providerTradeWindowRef
          expectedPriceTime
          redEndTime
          subEndTime
          subscriptionSettlementPeriod
          redemptionSettlementPeriod
          id
        }
        id
      }
      tradeInputValidationErrors {
        errorCode
        errorText
        id
      }
      tradeBusinessRulesValidationErrors {
        errorCode
        errorMessage
        errorLevel
        id
      }
      tradeComplianceRulesValidationErrors {
        errorCode
        errorMessage
        errorLevel
        id
      }
    }
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = [
  {
    "kind": "LocalArgument",
    "name": "input",
    "type": "OrderRequestsInput!",
    "defaultValue": null
  }
],
v1 = [
  {
    "kind": "Variable",
    "name": "input",
    "variableName": "input",
    "type": "OrderRequestsInput!"
  }
],
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v3 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderResponsesId",
  "args": null,
  "storageKey": null
},
v4 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "tradeValidationSummaryMessages",
  "args": null,
  "storageKey": null
},
v5 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderResponseId",
  "args": null,
  "storageKey": null
},
v6 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionFeeType",
  "args": null,
  "storageKey": null
},
v7 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "orderRequest",
  "storageKey": null,
  "args": null,
  "concreteType": "OrderRequest",
  "plural": false,
  "selections": [
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "overriddenSettlementPeriod",
      "args": null,
      "storageKey": null
    },
    v2,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "side",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "qtyType",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "quantity",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "tradeDate",
      "args": null,
      "storageKey": null
    },
    v6,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "fundAccountId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "userTradeWindowId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "investorCashSettlementInstruction",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "investorCustodySettlementInstruction",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "investorPaymentInstruction",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "comments",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "approvalMessage",
      "args": null,
      "storageKey": null
    }
  ]
},
v8 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "name",
  "args": null,
  "storageKey": null
},
v9 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "autoPopulateDefaultSsi",
  "args": null,
  "storageKey": null
},
v10 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "currencyCode",
  "args": null,
  "storageKey": null
},
v11 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "stale",
  "args": null,
  "storageKey": null
},
v12 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "balance",
  "storageKey": null,
  "args": null,
  "concreteType": "Balance",
  "plural": false,
  "selections": [
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "accruedAmt",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "balanceDt",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "balanceAmt",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "balanceAmtUSDE",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "estimatedMarketValue",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "estimatedMarketValueUSDE",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "shares",
      "args": null,
      "storageKey": null
    },
    v10,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "value",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "percentageOwned",
      "args": null,
      "storageKey": null
    },
    v11,
    {
      "kind": "LinkedField",
      "alias": null,
      "name": "fxRateDTO",
      "storageKey": null,
      "args": null,
      "concreteType": "FxRate",
      "plural": false,
      "selections": [
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "usdMid",
          "args": null,
          "storageKey": null
        },
        v11,
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "effectiveDate",
          "args": null,
          "storageKey": null
        }
      ]
    }
  ]
},
v13 = [
  v8
],
v14 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionGate",
  "args": null,
  "storageKey": null
},
v15 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionFeeInEffect",
  "args": null,
  "storageKey": null
},
v16 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundRoutingAutoSettlementSupported",
  "args": null,
  "storageKey": null
},
v17 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "providerSettlementInstructionAssociated",
  "args": null,
  "storageKey": null
},
v18 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "autoSettlementModel",
  "args": null,
  "storageKey": null
},
v19 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "defaultPrice",
  "args": null,
  "storageKey": null
},
v20 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "stableNav",
  "args": null,
  "storageKey": null
},
v21 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionFeePct",
  "args": null,
  "storageKey": null
},
v22 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundId",
  "args": null,
  "storageKey": null
},
v23 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "supportTradeWindows",
  "args": null,
  "storageKey": null
},
v24 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundType",
  "args": null,
  "storageKey": null
},
v25 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subscriptionGate",
  "args": null,
  "storageKey": null
},
v26 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "longName",
  "args": null,
  "storageKey": null
},
v27 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "settlementPeriod",
  "args": null,
  "storageKey": null
},
v28 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "overrideSettlementDate",
  "args": null,
  "storageKey": null
},
v29 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "supportedRedemptionFeeTypes",
  "args": null,
  "storageKey": null
},
v30 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subCutoffTime",
  "args": null,
  "storageKey": null
},
v31 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subCutoffTimeType",
  "args": null,
  "storageKey": null
},
v32 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redCutoffTime",
  "args": null,
  "storageKey": null
},
v33 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redCutoffTimeType",
  "args": null,
  "storageKey": null
},
v34 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "buy",
  "args": null,
  "storageKey": null
},
v35 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "sell",
  "args": null,
  "storageKey": null
},
v36 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "displayName",
  "args": null,
  "storageKey": null
},
v37 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodianName",
  "args": null,
  "storageKey": null
},
v38 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodianAccount",
  "args": null,
  "storageKey": null
},
v39 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodianBIC",
  "args": null,
  "storageKey": null
},
v40 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "defaultCurrencySSI",
  "args": null,
  "storageKey": null
},
v41 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "cashInstructions",
  "storageKey": null,
  "args": null,
  "concreteType": "CashInstruction",
  "plural": true,
  "selections": [
    v2,
    v36,
    v37,
    v38,
    v39,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "cashCutoffTimeDisplay",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "cashInstructionId",
      "args": null,
      "storageKey": null
    },
    v40
  ]
},
v42 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodyInstructionId",
  "args": null,
  "storageKey": null
},
v43 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "startTime",
  "args": null,
  "storageKey": null
},
v44 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "endTime",
  "args": null,
  "storageKey": null
},
v45 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundTimezoneName",
  "args": null,
  "storageKey": null
},
v46 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "tradeWindowsId",
  "args": null,
  "storageKey": null
},
v47 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "providerTradeWindowRef",
  "args": null,
  "storageKey": null
},
v48 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "expectedPriceTime",
  "args": null,
  "storageKey": null
},
v49 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redEndTime",
  "args": null,
  "storageKey": null
},
v50 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subEndTime",
  "args": null,
  "storageKey": null
},
v51 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subscriptionSettlementPeriod",
  "args": null,
  "storageKey": null
},
v52 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionSettlementPeriod",
  "args": null,
  "storageKey": null
},
v53 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "errorCode",
  "args": null,
  "storageKey": null
},
v54 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "errorText",
  "args": null,
  "storageKey": null
},
v55 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "errorMessage",
  "args": null,
  "storageKey": null
},
v56 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "errorLevel",
  "args": null,
  "storageKey": null
},
v57 = [
  v53,
  v55,
  v56
],
v58 = [
  v8,
  v2
],
v59 = [
  v53,
  v55,
  v56,
  v2
];
return {
  "kind": "Request",
  "operationKind": "mutation",
  "name": "MMFOrderEntryFormMutation",
  "id": null,
  "text": "mutation MMFOrderEntryFormMutation(\n  $input: OrderRequestsInput!\n) {\n  enterOrders(input: $input) {\n    id\n    orderResponsesId\n    tradeValidationSummaryMessages\n    orderResponses {\n      id\n      orderResponseId\n      orderRequest {\n        id\n        fundAccountId\n        side\n        qtyType\n        quantity\n        tradeDate\n        redemptionFeeType\n        overriddenSettlementPeriod\n        userTradeWindowId\n        investorCashSettlementInstruction\n        investorCustodySettlementInstruction\n        investorPaymentInstruction\n        comments\n        approvalMessage\n      }\n      fundAccount {\n        account {\n          name\n          autoPopulateDefaultSsi\n          id\n        }\n        balance {\n          balanceDt\n          shares\n          balanceAmt\n          balanceAmtUSDE\n          estimatedMarketValue\n          estimatedMarketValueUSDE\n          accruedAmt\n          currencyCode\n          value\n          percentageOwned\n          stale\n          fxRateDTO {\n            usdMid\n            stale\n            effectiveDate\n          }\n        }\n        fund {\n          redemptionGate\n          subscriptionGate\n          redemptionFeeInEffect\n          fundRoutingAutoSettlementSupported\n          providerSettlementInstructionAssociated\n          autoSettlementModel\n          defaultPrice\n          stableNav\n          redemptionFeeType\n          redemptionFeePct\n          id\n          fundId\n          supportTradeWindows\n          fundType\n          provider {\n            name\n            id\n          }\n          name\n          longName\n          fundCategory {\n            name\n            id\n          }\n          fundSubCategory {\n            name\n            id\n          }\n          currency {\n            currencyCode\n            id\n          }\n          domicileCountry {\n            name\n            id\n          }\n          settlementPeriod\n          overrideSettlementDate\n          supportedRedemptionFeeTypes\n          subCutoffTime\n          subCutoffTimeType\n          redCutoffTime\n          redCutoffTimeType\n        }\n        supportedQtyTypes {\n          buy\n          sell\n          id\n        }\n        cashInstructions {\n          id\n          displayName\n          custodianName\n          custodianAccount\n          custodianBIC\n          cashCutoffTimeDisplay\n          cashInstructionId\n          defaultCurrencySSI\n        }\n        custodyInstructions {\n          displayName\n          custodianName\n          custodianAccount\n          custodianBIC\n          custodyInstructionId\n          defaultCurrencySSI\n          id\n        }\n        tradeWindows {\n          startTime\n          endTime\n          fundTimezoneName\n          tradeWindowsId\n          providerTradeWindowRef\n          expectedPriceTime\n          redEndTime\n          subEndTime\n          subscriptionSettlementPeriod\n          redemptionSettlementPeriod\n          id\n        }\n        id\n      }\n      tradeInputValidationErrors {\n        errorCode\n        errorText\n        id\n      }\n      tradeBusinessRulesValidationErrors {\n        errorCode\n        errorMessage\n        errorLevel\n        id\n      }\n      tradeComplianceRulesValidationErrors {\n        errorCode\n        errorMessage\n        errorLevel\n        id\n      }\n    }\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "MMFOrderEntryFormMutation",
    "type": "Mutation",
    "metadata": null,
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "enterOrders",
        "storageKey": null,
        "args": v1,
        "concreteType": "OrderResponses",
        "plural": false,
        "selections": [
          v2,
          v3,
          v4,
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "orderResponses",
            "storageKey": null,
            "args": null,
            "concreteType": "OrderResponse",
            "plural": true,
            "selections": [
              v2,
              v5,
              v7,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "fundAccount",
                "storageKey": null,
                "args": null,
                "concreteType": "FundAccount",
                "plural": false,
                "selections": [
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "account",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Account",
                    "plural": false,
                    "selections": [
                      v8,
                      v9
                    ]
                  },
                  v12,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "fund",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Fund",
                    "plural": false,
                    "selections": [
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "provider",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Provider",
                        "plural": false,
                        "selections": v13
                      },
                      v14,
                      v15,
                      v16,
                      v17,
                      v18,
                      v19,
                      v20,
                      v6,
                      v21,
                      v2,
                      v22,
                      v23,
                      v24,
                      v25,
                      v8,
                      v26,
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "fundCategory",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "FundSubCategory",
                        "plural": false,
                        "selections": v13
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "fundSubCategory",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "FundCategory",
                        "plural": false,
                        "selections": v13
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "currency",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Currency",
                        "plural": false,
                        "selections": [
                          v10
                        ]
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "domicileCountry",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "DomicileCountry",
                        "plural": false,
                        "selections": v13
                      },
                      v27,
                      v28,
                      v29,
                      v30,
                      v31,
                      v32,
                      v33
                    ]
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "supportedQtyTypes",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "QtyTypes",
                    "plural": false,
                    "selections": [
                      v34,
                      v35
                    ]
                  },
                  v41,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "custodyInstructions",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "CustodyInstruction",
                    "plural": true,
                    "selections": [
                      v36,
                      v37,
                      v38,
                      v39,
                      v42,
                      v40
                    ]
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "tradeWindows",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "TradeWindows",
                    "plural": true,
                    "selections": [
                      v43,
                      v44,
                      v45,
                      v46,
                      v47,
                      v48,
                      v49,
                      v50,
                      v51,
                      v52
                    ]
                  }
                ]
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeInputValidationErrors",
                "storageKey": null,
                "args": null,
                "concreteType": "FCErrorType",
                "plural": true,
                "selections": [
                  v53,
                  v54
                ]
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeBusinessRulesValidationErrors",
                "storageKey": null,
                "args": null,
                "concreteType": "TradeValidationErrorType",
                "plural": true,
                "selections": v57
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeComplianceRulesValidationErrors",
                "storageKey": null,
                "args": null,
                "concreteType": "TradeValidationErrorType",
                "plural": true,
                "selections": v57
              }
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "MMFOrderEntryFormMutation",
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "enterOrders",
        "storageKey": null,
        "args": v1,
        "concreteType": "OrderResponses",
        "plural": false,
        "selections": [
          v2,
          v3,
          v4,
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "orderResponses",
            "storageKey": null,
            "args": null,
            "concreteType": "OrderResponse",
            "plural": true,
            "selections": [
              v2,
              v5,
              v7,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "fundAccount",
                "storageKey": null,
                "args": null,
                "concreteType": "FundAccount",
                "plural": false,
                "selections": [
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "account",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Account",
                    "plural": false,
                    "selections": [
                      v8,
                      v9,
                      v2
                    ]
                  },
                  v12,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "fund",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Fund",
                    "plural": false,
                    "selections": [
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "provider",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Provider",
                        "plural": false,
                        "selections": v58
                      },
                      v14,
                      v15,
                      v16,
                      v17,
                      v18,
                      v19,
                      v20,
                      v6,
                      v21,
                      v2,
                      v22,
                      v23,
                      v24,
                      v25,
                      v8,
                      v26,
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "fundCategory",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "FundSubCategory",
                        "plural": false,
                        "selections": v58
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "fundSubCategory",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "FundCategory",
                        "plural": false,
                        "selections": v58
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "currency",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Currency",
                        "plural": false,
                        "selections": [
                          v10,
                          v2
                        ]
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "domicileCountry",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "DomicileCountry",
                        "plural": false,
                        "selections": v58
                      },
                      v27,
                      v28,
                      v29,
                      v30,
                      v31,
                      v32,
                      v33
                    ]
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "supportedQtyTypes",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "QtyTypes",
                    "plural": false,
                    "selections": [
                      v34,
                      v35,
                      v2
                    ]
                  },
                  v41,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "custodyInstructions",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "CustodyInstruction",
                    "plural": true,
                    "selections": [
                      v36,
                      v37,
                      v38,
                      v39,
                      v42,
                      v40,
                      v2
                    ]
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "tradeWindows",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "TradeWindows",
                    "plural": true,
                    "selections": [
                      v48,
                      v43,
                      v45,
                      v46,
                      v47,
                      v44,
                      v49,
                      v50,
                      v51,
                      v52,
                      v2
                    ]
                  },
                  v2
                ]
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeInputValidationErrors",
                "storageKey": null,
                "args": null,
                "concreteType": "FCErrorType",
                "plural": true,
                "selections": [
                  v53,
                  v54,
                  v2
                ]
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeBusinessRulesValidationErrors",
                "storageKey": null,
                "args": null,
                "concreteType": "TradeValidationErrorType",
                "plural": true,
                "selections": v59
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeComplianceRulesValidationErrors",
                "storageKey": null,
                "args": null,
                "concreteType": "TradeValidationErrorType",
                "plural": true,
                "selections": v59
              }
            ]
          }
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = '2d60509e179659a6bc27a8a01cda396d';
module.exports = node;
