import React, { PureComponent } from 'react'
import { FormSection } from 'redux-form'
import PropTypes from 'prop-types'
import _ from 'lodash'
import MMFOrderEntryFormOrder from './MMFOrderEntryFormOrder'

import { OrderEntryConsumer } from '../../routes/OrderEntryRoute/OrderEntryRouteContext'

class MMFOrderEntryFormAccountList extends PureComponent {
  static propTypes = {
    fields: PropTypes.shape({
      map: PropTypes.func,
    }),
  }

  render() {
    const { fields, ...rest } = this.props
    return fields.map((member, index) => {
      const account = fields.get(index)
      return (
        <OrderEntryConsumer key={member}>
          {({
            fundAccountsByIds,
            onOrderSelectionChange,
            setDefaultSSI,
            accountType,
          }) => {
            const additionalAccountInfo = _.find(
              fundAccountsByIds,
              ({ id }) => account.id === id,
            )
            const mergedAccount = _.merge({}, additionalAccountInfo, account)
            return (
              <FormSection name={member}>
                <MMFOrderEntryFormOrder
                  member={member}
                  data={mergedAccount}
                  {...rest}
                  onOrderSelectionChange={onOrderSelectionChange}
                  setDefaultSSI={setDefaultSSI}
                  accountType={accountType}
                />
              </FormSection>
            )
          }}
        </OrderEntryConsumer>
      )
    })
  }
}

export default MMFOrderEntryFormAccountList
