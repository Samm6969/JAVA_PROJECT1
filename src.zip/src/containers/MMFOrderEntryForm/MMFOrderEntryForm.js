import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import PropTypes from 'prop-types'
import { graphql } from 'react-relay'
import { FieldArray } from 'redux-form'
import _ from 'lodash'
import moment from 'moment'

import commitMutation from '../../utils/commitMutation'
import MMFOrderEntryFormFundGroup from './MMFOrderEntryFormFundGroup'
import reduxForm from '../../hoc/reduxForm'

const getFieldValues = values => {
  const payloadList = []
  _.forEach(values.selected, value => {
    const accounts = _.get(value, 'accounts')
    _.forEach(accounts, account => {
      if (_.isUndefined(account.selectedForTrade) || !account.selectedForTrade)
        return
      const { id, order } = account
      const {
        orderSide,
        quantityType,
        amount,
        comment,
        commentToApproval,
        redemptionType,
        settlementDate,
        tradeWindow,
        tradeDate,
        cashSettlementInstructions,
        custodySettlementInstructions,
      } = order

      // console.log(cashSettlementInstructions)
      // TODO: trade date change to ISO time when server changes it

      const orderRequest = {
        fundAccountId: id,
        side: _.toUpper(orderSide.label),
        qtyType: _.toUpper(quantityType.label),
        quantity: parseFloat(amount.value),
        tradeDate:
          typeof tradeDate === 'object'
            ? tradeDate.format('YYYY-MM-DD')
            : moment(tradeDate, 'MM/DD/YYYY').format('YYYY-MM-DD'),
        comments: comment,
        approvalMessage: commentToApproval,
        redemptionFeeType:
          redemptionType && redemptionType.value ? redemptionType.value : null,
        overriddenSettlementPeriod: settlementDate
          ? settlementDate.value
          : null,
        userTradeWindowId:
          tradeWindow && !_.isUndefined(tradeWindow.tradeWindowsId)
            ? parseInt(tradeWindow.tradeWindowsId, 10)
            : null,
        investorCashSettlementInstruction:
          cashSettlementInstructions &&
          !_.isUndefined(cashSettlementInstructions.cashInstructionId)
            ? parseInt(cashSettlementInstructions.cashInstructionId, 10)
            : null,
        investorCustodySettlementInstruction:
          custodySettlementInstructions &&
          !_.isUndefined(custodySettlementInstructions.custodyInstructionId)
            ? parseInt(custodySettlementInstructions.custodyInstructionId, 10)
            : null,
      }

      // console.log(orderRequest)
      payloadList.push(orderRequest)
    })
  })
  return payloadList
}

const onSubmit = async (values, dispatch, props) => {
  const { history } = props
  const payLoadList = getFieldValues(values)
  const mutation = graphql`
    mutation MMFOrderEntryFormMutation($input: OrderRequestsInput!) {
      enterOrders(input: $input) {
        id
        orderResponsesId
        tradeValidationSummaryMessages
        orderResponses {
          id
          orderResponseId
          orderRequest {
            id
            fundAccountId
            side
            qtyType
            quantity
            tradeDate
            redemptionFeeType
            overriddenSettlementPeriod
            userTradeWindowId
            investorCashSettlementInstruction
            investorCustodySettlementInstruction
            investorPaymentInstruction
            comments
            approvalMessage
          }
          fundAccount {
            account {
              name
              autoPopulateDefaultSsi
            }
            balance {
              balanceDt
              shares
              balanceAmt
              balanceAmtUSDE
              estimatedMarketValue
              estimatedMarketValueUSDE
              accruedAmt
              currencyCode
              value
              percentageOwned
              stale
              fxRateDTO {
                usdMid
                stale
                effectiveDate
              }
            }
            fund {
              redemptionGate
              subscriptionGate
              redemptionFeeInEffect
              fundRoutingAutoSettlementSupported
              providerSettlementInstructionAssociated
              autoSettlementModel
              defaultPrice
              stableNav
              redemptionFeeType
              redemptionFeePct
              redemptionGate
              id
              fundId
              supportTradeWindows
              fundType
              provider {
                name
              }
              name
              longName
              fundCategory {
                name
              }
              fundSubCategory {
                name
              }
              currency {
                currencyCode
              }
              domicileCountry {
                name
              }
              settlementPeriod
              overrideSettlementDate
              supportedRedemptionFeeTypes
              subCutoffTime
              subCutoffTimeType
              redCutoffTime
              redCutoffTimeType
              redemptionFeeInEffect
            }
            supportedQtyTypes {
              buy
              sell
            }
            cashInstructions {
              id
              displayName
              custodianName
              custodianAccount
              custodianBIC
              cashCutoffTimeDisplay
              cashInstructionId
              defaultCurrencySSI
            }
            custodyInstructions {
              displayName
              custodianName
              custodianAccount
              custodianBIC
              custodyInstructionId
              defaultCurrencySSI
            }
            tradeWindows {
              startTime
              endTime
              fundTimezoneName
              tradeWindowsId
              providerTradeWindowRef
              expectedPriceTime
              redEndTime
              subEndTime
              subscriptionSettlementPeriod
              redemptionSettlementPeriod
            }
          }
          tradeInputValidationErrors {
            errorCode
            errorText
          }
          tradeBusinessRulesValidationErrors {
            errorCode
            errorMessage
            errorLevel
          }
          tradeComplianceRulesValidationErrors {
            errorCode
            errorMessage
            errorLevel
          }
        }
      }
    }
  `
  try {
    await commitMutation({
      mutation,
      variables: {
        input: {
          clientMutationId: _.uniqueId('mmf-order-request'),
          orderRequests: payLoadList,
        },
      },
      onCompleted: res => {
        // console.log(res)
        const location = {
          pathname: '/trade/direct/short-term/order-confirm',
          state: {
            enterOrderPayload: payLoadList,
            response: res,
          },
        }
        history.push(location)
      },
    })
  } catch (error) {
    // eslint-disable-next-line no-console
    console.error(error)
  }
}
@withRouter
@reduxForm({
  onSubmit,
  destroyOnUnmount: false,
  forceUnregisterOnUnmount: true,
})
class MMFOrderEntryForm extends Component {
  static propTypes = {
    handleSubmit: PropTypes.func,
  }

  render() {
    const { handleSubmit } = this.props
    return (
      <form onSubmit={handleSubmit} suppressHydrationWarning>
        <FieldArray name="selected" component={MMFOrderEntryFormFundGroup} />
      </form>
    )
  }
}

export default MMFOrderEntryForm
