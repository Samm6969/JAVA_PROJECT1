/**
 * @flow
 * @relayHash 52273d74401974d3e33a00dd835d5a74
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type AccountTypeEnum = "FULLY_DISCLOSED" | "OMNI" | "%future added value";
export type AccountSelectorQueryVariables = {|
  institutionLocationId?: ?string
|};
export type AccountSelectorQueryResponse = {|
  +viewer: ?{|
    +accountsByInstitutionLocation: ?$ReadOnlyArray<?{|
      +id: string,
      +name: ?string,
      +accountType: ?AccountTypeEnum,
      +client: ?{|
        +name: ?string
      |},
      +division: ?{|
        +name: ?string
      |},
      +tradeInstitution: ?{|
        +location: ?{|
          +name: ?string
        |},
        +institution: ?{|
          +name: ?string
        |},
      |},
    |}>
  |}
|};
export type AccountSelectorQuery = {|
  variables: AccountSelectorQueryVariables,
  response: AccountSelectorQueryResponse,
|};
*/


/*
query AccountSelectorQuery(
  $institutionLocationId: ID
) {
  viewer {
    accountsByInstitutionLocation(institutionLocationId: $institutionLocationId) {
      id
      name
      accountType
      client {
        name
        id
      }
      division {
        name
        id
      }
      tradeInstitution {
        location {
          name
          id
        }
        institution {
          name
          id
        }
        id
      }
    }
    id
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = [
  {
    "kind": "LocalArgument",
    "name": "institutionLocationId",
    "type": "ID",
    "defaultValue": null
  }
],
v1 = [
  {
    "kind": "Variable",
    "name": "institutionLocationId",
    "variableName": "institutionLocationId",
    "type": "ID"
  }
],
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v3 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "name",
  "args": null,
  "storageKey": null
},
v4 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "accountType",
  "args": null,
  "storageKey": null
},
v5 = [
  v3
],
v6 = [
  v3,
  v2
];
return {
  "kind": "Request",
  "operationKind": "query",
  "name": "AccountSelectorQuery",
  "id": null,
  "text": "query AccountSelectorQuery(\n  $institutionLocationId: ID\n) {\n  viewer {\n    accountsByInstitutionLocation(institutionLocationId: $institutionLocationId) {\n      id\n      name\n      accountType\n      client {\n        name\n        id\n      }\n      division {\n        name\n        id\n      }\n      tradeInstitution {\n        location {\n          name\n          id\n        }\n        institution {\n          name\n          id\n        }\n        id\n      }\n    }\n    id\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "AccountSelectorQuery",
    "type": "Root",
    "metadata": null,
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "accountsByInstitutionLocation",
            "storageKey": null,
            "args": v1,
            "concreteType": "Account",
            "plural": true,
            "selections": [
              v2,
              v3,
              v4,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "client",
                "storageKey": null,
                "args": null,
                "concreteType": "ClientType",
                "plural": false,
                "selections": v5
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "division",
                "storageKey": null,
                "args": null,
                "concreteType": "Division",
                "plural": false,
                "selections": v5
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeInstitution",
                "storageKey": null,
                "args": null,
                "concreteType": "InstitutionLocation",
                "plural": false,
                "selections": [
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "location",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Location",
                    "plural": false,
                    "selections": v5
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "institution",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Institution",
                    "plural": false,
                    "selections": v5
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "AccountSelectorQuery",
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "accountsByInstitutionLocation",
            "storageKey": null,
            "args": v1,
            "concreteType": "Account",
            "plural": true,
            "selections": [
              v2,
              v3,
              v4,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "client",
                "storageKey": null,
                "args": null,
                "concreteType": "ClientType",
                "plural": false,
                "selections": v6
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "division",
                "storageKey": null,
                "args": null,
                "concreteType": "Division",
                "plural": false,
                "selections": v6
              },
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "tradeInstitution",
                "storageKey": null,
                "args": null,
                "concreteType": "InstitutionLocation",
                "plural": false,
                "selections": [
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "location",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Location",
                    "plural": false,
                    "selections": v6
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "institution",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Institution",
                    "plural": false,
                    "selections": v6
                  },
                  v2
                ]
              }
            ]
          },
          v2
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = 'a68601723648d6f1f8af360fdc47654d';
module.exports = node;
