import React, { Component } from 'react'
// import PropTypes from 'prop-types'
// import cx from 'classnames'

import { Card, CardHeader, CardTitle, FillContainer } from '@fc/react-playbook'

import TradeBlotterGrid from '../TradeBlotterGrid'
import TradeBlotterFilters from './TradeBlotterFilters'
// import FlexColumnLayout from '../../components/FlexColumnLayout'

class TradeBlotter extends Component {
  state = {
    selectedStatus: 'ALL',
    counts: {},
  }
  /* TODO: Filters
      Settlement Approval Required
  */

  handleFilterChange = status => {
    this.setState({
      selectedStatus: status,
    })
  }

  updateCounts = counts => {
    this.setState({
      counts,
    })
  }

  render() {
    const { counts, selectedStatus } = this.state
    return (
      <FillContainer>
        <Card>
          <CardHeader>
            <CardTitle>
              Trade Blotter |{' '}
              <TradeBlotterFilters
                counts={counts}
                selectedStatus={selectedStatus}
                handleFilterChange={this.handleFilterChange}
              />
            </CardTitle>
          </CardHeader>
          <TradeBlotterGrid
            id="trade-blotter-grid"
            selectedStatus={selectedStatus}
            updateCounts={this.updateCounts}
          />
        </Card>
      </FillContainer>
    )
  }
}

export default TradeBlotter
