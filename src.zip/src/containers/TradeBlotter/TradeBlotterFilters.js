import React from 'react'
import PropTypes from 'prop-types'

import FilterButton from './FilterButton'

const Filters = [
  {
    filterName: 'APPRV_REQ',
    displayName: 'Approval Required',
    badgeType: 'warn',
  },
  {
    filterName: 'SUBMITTED',
    displayName: 'Submitted',
  },
  {
    filterName: 'PENDING_REVIEW',
    displayName: 'Pending Review',
  },
  {
    filterName: 'IN_PROGRESS',
    displayName: 'In Progress',
  },
  {
    filterName: 'COMPLETED',
    displayName: 'Completed',
    badgeType: 'success',
  },
  {
    filterName: 'REJECTED',
    displayName: 'Rejected',
    badgeType: 'error',
  },
  {
    filterName: 'APPRV_DENIED',
    displayName: 'Approval Denied',
  },
]

const TradeBlotterFilters = ({
  // eslint-disable-next-line no-unused-vars
  selectedStatus,
  handleFilterChange,
  counts,
}) => (
  <React.Fragment>
    {Filters.map(filter => (
      <FilterButton
        {...filter}
        counts={counts}
        handleClick={handleFilterChange}
      />
    ))}
  </React.Fragment>
)
/*
  <Button onClick={() => handleFilterChange('ALL')}>All</Button>
  */

// TODO: Figure out Settlement Approval Required

TradeBlotterFilters.propTypes = {
  selectedStatus: PropTypes.string,
  handleFilterChange: PropTypes.func,
  // eslint-disable-next-line react/forbid-prop-types
  counts: PropTypes.any,
}

export default TradeBlotterFilters
