import React from 'react'
import PropTypes from 'prop-types'
import { Badge, Button } from '@fc/react-playbook'

const FilterButton = ({
  filterName,
  displayName,
  badgeType = 'default',
  counts,
  handleClick,
}) => (
  <Button onClick={() => handleClick(filterName)}>
    <Badge type={badgeType}>{counts[filterName] || 0}</Badge>
    {displayName}
  </Button>
)

FilterButton.propTypes = {
  filterName: PropTypes.string.isRequired,
  displayName: PropTypes.string.isRequired,
  badgeType: Badge.propTypes.type,
  handleClick: PropTypes.func,
  counts: PropTypes.objectOf(PropTypes.number),
}

export default FilterButton
