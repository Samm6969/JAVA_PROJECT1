/**
 * @flow
 * @relayHash 5eed987b7375aff29becb51486cec02d
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type AutoSettlementModelEnum = "PLATFORM" | "REGISTERED" | "%future added value";
export type RedemptionFeeTypeEnum = "GROSS" | "NET" | "%future added value";
export type InvestmentOptionsGridQueryVariables = {|
  institutionLocationId?: ?string,
  accountIds?: ?$ReadOnlyArray<?string>,
  accountType?: ?string,
  fundType?: ?string,
|};
export type InvestmentOptionsGridQueryResponse = {|
  +viewer: ?{|
    +fundAccountsForInstitution: ?$ReadOnlyArray<?{|
      +id: string,
      +account: ?{|
        +autoPopulateDefaultSsi: ?boolean,
        +name: ?string,
        +division: ?{|
          +name: ?string
        |},
        +client: ?{|
          +name: ?string
        |},
        +executePermission: ?string,
        +tradeInstitution: ?{|
          +location: ?{|
            +name: ?string
          |},
          +institution: ?{|
            +name: ?string
          |},
        |},
      |},
      +balance: ?{|
        +balanceDt: ?string,
        +shares: ?number,
        +balanceAmt: ?number,
        +balanceAmtUSDE: ?number,
        +estimatedMarketValue: ?number,
        +estimatedMarketValueUSDE: ?number,
        +accruedAmt: ?number,
        +currencyCode: ?string,
        +value: ?number,
        +percentageOwned: ?number,
        +stale: ?boolean,
        +fxRateDTO: ?{|
          +usdMid: ?number,
          +stale: ?boolean,
          +effectiveDate: ?string,
        |},
      |},
      +fund: ?{|
        +id: string,
        +fundId: ?string,
        +fundType: ?string,
        +provider: ?{|
          +name: ?string
        |},
        +name: ?string,
        +longName: ?string,
        +fundCategory: ?{|
          +name: ?string
        |},
        +fundSubCategory: ?{|
          +name: ?string
        |},
        +currency: ?{|
          +currencyCode: ?string
        |},
        +domicileCountry: ?{|
          +name: ?string
        |},
        +autoSettlementModel: ?AutoSettlementModelEnum,
        +fundRoutingAutoSettlementSupported: ?boolean,
        +providerSettlementInstructionAssociated: ?boolean,
        +defaultPrice: ?string,
        +stableNav: ?boolean,
        +settlementPeriod: ?number,
        +contactName: ?string,
        +contactPhone: ?string,
        +cusip: ?string,
        +isin: ?string,
        +iso: ?string,
        +sedol: ?string,
        +ticker: ?string,
        +otherFundCode: ?string,
        +overrideSettlementDate: ?boolean,
        +supportedRedemptionFeeTypes: ?$ReadOnlyArray<?RedemptionFeeTypeEnum>,
        +expenseRatio: ?number,
        +fundWholeHoliday: ?boolean,
        +statistics: ?{|
          +fitchRating: ?string,
          +moodyRating: ?string,
          +naicRating: ?string,
          +spRating: ?string,
          +aum: ?number,
          +dailyFactor: ?number,
          +nav: ?number,
          +shadowNav: ?number,
          +netFlows: ?number,
          +wam: ?number,
          +yld1Day: ?number,
          +yld7Day: ?number,
          +yld30Day: ?number,
          +liquidity1Day: ?number,
          +liquidity7Day: ?number,
          +stale: ?boolean,
          +dtEffective: ?string,
          +priceStale: ?boolean,
          +priceDtEffective: ?string,
        |},
        +supportTradeWindows: ?boolean,
        +subCutoffTime: ?string,
        +subCutoffTimeType: ?string,
        +redCutoffTime: ?string,
        +redCutoffTimeType: ?string,
        +taxable: ?boolean,
        +earlyCloseOrHoliday: ?boolean,
        +redemptionFeeInEffect: ?boolean,
        +redemptionGate: ?boolean,
        +subscriptionGate: ?boolean,
      |},
      +tradeWindows: ?$ReadOnlyArray<?{|
        +id: string,
        +tradeWindowsId: ?number,
        +addedBy: ?string,
        +cobrandId: ?number,
        +endTime: ?string,
        +expectedPriceTime: ?string,
        +fundId: ?number,
        +fundTimezoneId: ?number,
        +fundTimezoneName: ?string,
        +invAccountId: ?number,
        +providerTradeWindowRef: ?string,
        +redEndTime: ?string,
        +redemptionSettlementPeriod: ?number,
        +startTime: ?string,
        +subEndTime: ?string,
        +subscriptionSettlementPeriod: ?number,
      |}>,
    |}>
  |}
|};
export type InvestmentOptionsGridQuery = {|
  variables: InvestmentOptionsGridQueryVariables,
  response: InvestmentOptionsGridQueryResponse,
|};
*/


/*
query InvestmentOptionsGridQuery(
  $institutionLocationId: ID
  $accountIds: [ID]
  $accountType: String
  $fundType: String
) {
  viewer {
    fundAccountsForInstitution(institutionLocationId: $institutionLocationId, accountIds: $accountIds, accountType: $accountType, fundType: $fundType) {
      id
      account {
        autoPopulateDefaultSsi
        name
        division {
          name
          id
        }
        client {
          name
          id
        }
        executePermission
        tradeInstitution {
          location {
            name
            id
          }
          institution {
            name
            id
          }
          id
        }
        id
      }
      balance {
        balanceDt
        shares
        balanceAmt
        balanceAmtUSDE
        estimatedMarketValue
        estimatedMarketValueUSDE
        accruedAmt
        currencyCode
        value
        percentageOwned
        stale
        fxRateDTO {
          usdMid
          stale
          effectiveDate
        }
      }
      fund {
        id
        fundId
        fundType
        provider {
          name
          id
        }
        name
        longName
        fundCategory {
          name
          id
        }
        fundSubCategory {
          name
          id
        }
        currency {
          currencyCode
          id
        }
        domicileCountry {
          name
          id
        }
        autoSettlementModel
        fundRoutingAutoSettlementSupported
        providerSettlementInstructionAssociated
        defaultPrice
        stableNav
        settlementPeriod
        contactName
        contactPhone
        cusip
        isin
        iso
        sedol
        ticker
        otherFundCode
        overrideSettlementDate
        supportedRedemptionFeeTypes
        expenseRatio
        fundWholeHoliday
        statistics {
          fitchRating
          moodyRating
          naicRating
          spRating
          aum
          dailyFactor
          nav
          shadowNav
          netFlows
          wam
          yld1Day
          yld7Day
          yld30Day
          liquidity1Day
          liquidity7Day
          stale
          dtEffective
          priceStale
          priceDtEffective
          id
        }
        supportTradeWindows
        subCutoffTime
        subCutoffTimeType
        redCutoffTime
        redCutoffTimeType
        taxable
        earlyCloseOrHoliday
        redemptionFeeInEffect
        redemptionGate
        subscriptionGate
      }
      tradeWindows {
        id
        tradeWindowsId
        addedBy
        cobrandId
        endTime
        expectedPriceTime
        fundId
        fundTimezoneId
        fundTimezoneName
        invAccountId
        providerTradeWindowRef
        redEndTime
        redemptionSettlementPeriod
        startTime
        subEndTime
        subscriptionSettlementPeriod
      }
    }
    id
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = [
  {
    "kind": "LocalArgument",
    "name": "institutionLocationId",
    "type": "ID",
    "defaultValue": null
  },
  {
    "kind": "LocalArgument",
    "name": "accountIds",
    "type": "[ID]",
    "defaultValue": null
  },
  {
    "kind": "LocalArgument",
    "name": "accountType",
    "type": "String",
    "defaultValue": null
  },
  {
    "kind": "LocalArgument",
    "name": "fundType",
    "type": "String",
    "defaultValue": null
  }
],
v1 = [
  {
    "kind": "Variable",
    "name": "accountIds",
    "variableName": "accountIds",
    "type": "[ID]"
  },
  {
    "kind": "Variable",
    "name": "accountType",
    "variableName": "accountType",
    "type": "String"
  },
  {
    "kind": "Variable",
    "name": "fundType",
    "variableName": "fundType",
    "type": "String"
  },
  {
    "kind": "Variable",
    "name": "institutionLocationId",
    "variableName": "institutionLocationId",
    "type": "ID"
  }
],
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v3 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "autoPopulateDefaultSsi",
  "args": null,
  "storageKey": null
},
v4 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "name",
  "args": null,
  "storageKey": null
},
v5 = [
  v4
],
v6 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "executePermission",
  "args": null,
  "storageKey": null
},
v7 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "currencyCode",
  "args": null,
  "storageKey": null
},
v8 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "stale",
  "args": null,
  "storageKey": null
},
v9 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "balance",
  "storageKey": null,
  "args": null,
  "concreteType": "Balance",
  "plural": false,
  "selections": [
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "accruedAmt",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "balanceDt",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "balanceAmt",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "balanceAmtUSDE",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "estimatedMarketValue",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "estimatedMarketValueUSDE",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "shares",
      "args": null,
      "storageKey": null
    },
    v7,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "value",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "percentageOwned",
      "args": null,
      "storageKey": null
    },
    v8,
    {
      "kind": "LinkedField",
      "alias": null,
      "name": "fxRateDTO",
      "storageKey": null,
      "args": null,
      "concreteType": "FxRate",
      "plural": false,
      "selections": [
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "usdMid",
          "args": null,
          "storageKey": null
        },
        v8,
        {
          "kind": "ScalarField",
          "alias": null,
          "name": "effectiveDate",
          "args": null,
          "storageKey": null
        }
      ]
    }
  ]
},
v10 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "isin",
  "args": null,
  "storageKey": null
},
v11 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundType",
  "args": null,
  "storageKey": null
},
v12 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "longName",
  "args": null,
  "storageKey": null
},
v13 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "autoSettlementModel",
  "args": null,
  "storageKey": null
},
v14 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundRoutingAutoSettlementSupported",
  "args": null,
  "storageKey": null
},
v15 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "providerSettlementInstructionAssociated",
  "args": null,
  "storageKey": null
},
v16 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "defaultPrice",
  "args": null,
  "storageKey": null
},
v17 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "stableNav",
  "args": null,
  "storageKey": null
},
v18 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "settlementPeriod",
  "args": null,
  "storageKey": null
},
v19 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "contactName",
  "args": null,
  "storageKey": null
},
v20 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "contactPhone",
  "args": null,
  "storageKey": null
},
v21 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "cusip",
  "args": null,
  "storageKey": null
},
v22 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundId",
  "args": null,
  "storageKey": null
},
v23 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "iso",
  "args": null,
  "storageKey": null
},
v24 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "sedol",
  "args": null,
  "storageKey": null
},
v25 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "ticker",
  "args": null,
  "storageKey": null
},
v26 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "otherFundCode",
  "args": null,
  "storageKey": null
},
v27 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "overrideSettlementDate",
  "args": null,
  "storageKey": null
},
v28 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "supportedRedemptionFeeTypes",
  "args": null,
  "storageKey": null
},
v29 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "expenseRatio",
  "args": null,
  "storageKey": null
},
v30 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundWholeHoliday",
  "args": null,
  "storageKey": null
},
v31 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "wam",
  "args": null,
  "storageKey": null
},
v32 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fitchRating",
  "args": null,
  "storageKey": null
},
v33 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "naicRating",
  "args": null,
  "storageKey": null
},
v34 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "spRating",
  "args": null,
  "storageKey": null
},
v35 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "aum",
  "args": null,
  "storageKey": null
},
v36 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "dailyFactor",
  "args": null,
  "storageKey": null
},
v37 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "nav",
  "args": null,
  "storageKey": null
},
v38 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "shadowNav",
  "args": null,
  "storageKey": null
},
v39 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "netFlows",
  "args": null,
  "storageKey": null
},
v40 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "moodyRating",
  "args": null,
  "storageKey": null
},
v41 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "yld1Day",
  "args": null,
  "storageKey": null
},
v42 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "yld7Day",
  "args": null,
  "storageKey": null
},
v43 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "yld30Day",
  "args": null,
  "storageKey": null
},
v44 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "liquidity1Day",
  "args": null,
  "storageKey": null
},
v45 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "liquidity7Day",
  "args": null,
  "storageKey": null
},
v46 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "dtEffective",
  "args": null,
  "storageKey": null
},
v47 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "priceStale",
  "args": null,
  "storageKey": null
},
v48 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "priceDtEffective",
  "args": null,
  "storageKey": null
},
v49 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "supportTradeWindows",
  "args": null,
  "storageKey": null
},
v50 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subCutoffTime",
  "args": null,
  "storageKey": null
},
v51 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subCutoffTimeType",
  "args": null,
  "storageKey": null
},
v52 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redCutoffTime",
  "args": null,
  "storageKey": null
},
v53 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redCutoffTimeType",
  "args": null,
  "storageKey": null
},
v54 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "taxable",
  "args": null,
  "storageKey": null
},
v55 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "earlyCloseOrHoliday",
  "args": null,
  "storageKey": null
},
v56 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionFeeInEffect",
  "args": null,
  "storageKey": null
},
v57 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "redemptionGate",
  "args": null,
  "storageKey": null
},
v58 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "subscriptionGate",
  "args": null,
  "storageKey": null
},
v59 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "tradeWindows",
  "storageKey": null,
  "args": null,
  "concreteType": "TradeWindows",
  "plural": true,
  "selections": [
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "fundTimezoneName",
      "args": null,
      "storageKey": null
    },
    v2,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "addedBy",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "cobrandId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "endTime",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "expectedPriceTime",
      "args": null,
      "storageKey": null
    },
    v22,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "fundTimezoneId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "tradeWindowsId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "invAccountId",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "providerTradeWindowRef",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "redEndTime",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "redemptionSettlementPeriod",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "startTime",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "subEndTime",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "subscriptionSettlementPeriod",
      "args": null,
      "storageKey": null
    }
  ]
},
v60 = [
  v4,
  v2
];
return {
  "kind": "Request",
  "operationKind": "query",
  "name": "InvestmentOptionsGridQuery",
  "id": null,
  "text": "query InvestmentOptionsGridQuery(\n  $institutionLocationId: ID\n  $accountIds: [ID]\n  $accountType: String\n  $fundType: String\n) {\n  viewer {\n    fundAccountsForInstitution(institutionLocationId: $institutionLocationId, accountIds: $accountIds, accountType: $accountType, fundType: $fundType) {\n      id\n      account {\n        autoPopulateDefaultSsi\n        name\n        division {\n          name\n          id\n        }\n        client {\n          name\n          id\n        }\n        executePermission\n        tradeInstitution {\n          location {\n            name\n            id\n          }\n          institution {\n            name\n            id\n          }\n          id\n        }\n        id\n      }\n      balance {\n        balanceDt\n        shares\n        balanceAmt\n        balanceAmtUSDE\n        estimatedMarketValue\n        estimatedMarketValueUSDE\n        accruedAmt\n        currencyCode\n        value\n        percentageOwned\n        stale\n        fxRateDTO {\n          usdMid\n          stale\n          effectiveDate\n        }\n      }\n      fund {\n        id\n        fundId\n        fundType\n        provider {\n          name\n          id\n        }\n        name\n        longName\n        fundCategory {\n          name\n          id\n        }\n        fundSubCategory {\n          name\n          id\n        }\n        currency {\n          currencyCode\n          id\n        }\n        domicileCountry {\n          name\n          id\n        }\n        autoSettlementModel\n        fundRoutingAutoSettlementSupported\n        providerSettlementInstructionAssociated\n        defaultPrice\n        stableNav\n        settlementPeriod\n        contactName\n        contactPhone\n        cusip\n        isin\n        iso\n        sedol\n        ticker\n        otherFundCode\n        overrideSettlementDate\n        supportedRedemptionFeeTypes\n        expenseRatio\n        fundWholeHoliday\n        statistics {\n          fitchRating\n          moodyRating\n          naicRating\n          spRating\n          aum\n          dailyFactor\n          nav\n          shadowNav\n          netFlows\n          wam\n          yld1Day\n          yld7Day\n          yld30Day\n          liquidity1Day\n          liquidity7Day\n          stale\n          dtEffective\n          priceStale\n          priceDtEffective\n          id\n        }\n        supportTradeWindows\n        subCutoffTime\n        subCutoffTimeType\n        redCutoffTime\n        redCutoffTimeType\n        taxable\n        earlyCloseOrHoliday\n        redemptionFeeInEffect\n        redemptionGate\n        subscriptionGate\n      }\n      tradeWindows {\n        id\n        tradeWindowsId\n        addedBy\n        cobrandId\n        endTime\n        expectedPriceTime\n        fundId\n        fundTimezoneId\n        fundTimezoneName\n        invAccountId\n        providerTradeWindowRef\n        redEndTime\n        redemptionSettlementPeriod\n        startTime\n        subEndTime\n        subscriptionSettlementPeriod\n      }\n    }\n    id\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "InvestmentOptionsGridQuery",
    "type": "Root",
    "metadata": null,
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "fundAccountsForInstitution",
            "storageKey": null,
            "args": v1,
            "concreteType": "FundAccount",
            "plural": true,
            "selections": [
              v2,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "account",
                "storageKey": null,
                "args": null,
                "concreteType": "Account",
                "plural": false,
                "selections": [
                  v3,
                  v4,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "division",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Division",
                    "plural": false,
                    "selections": v5
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "client",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "ClientType",
                    "plural": false,
                    "selections": v5
                  },
                  v6,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "tradeInstitution",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "InstitutionLocation",
                    "plural": false,
                    "selections": [
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "location",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Location",
                        "plural": false,
                        "selections": v5
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "institution",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Institution",
                        "plural": false,
                        "selections": v5
                      }
                    ]
                  }
                ]
              },
              v9,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "fund",
                "storageKey": null,
                "args": null,
                "concreteType": "Fund",
                "plural": false,
                "selections": [
                  v10,
                  v2,
                  v11,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "provider",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Provider",
                    "plural": false,
                    "selections": v5
                  },
                  v4,
                  v12,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "fundCategory",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "FundSubCategory",
                    "plural": false,
                    "selections": v5
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "fundSubCategory",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "FundCategory",
                    "plural": false,
                    "selections": v5
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "currency",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Currency",
                    "plural": false,
                    "selections": [
                      v7
                    ]
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "domicileCountry",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "DomicileCountry",
                    "plural": false,
                    "selections": v5
                  },
                  v13,
                  v14,
                  v15,
                  v16,
                  v17,
                  v18,
                  v19,
                  v20,
                  v21,
                  v22,
                  v23,
                  v24,
                  v25,
                  v26,
                  v27,
                  v28,
                  v29,
                  v30,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "statistics",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Statistics",
                    "plural": false,
                    "selections": [
                      v31,
                      v32,
                      v33,
                      v34,
                      v35,
                      v36,
                      v37,
                      v38,
                      v39,
                      v40,
                      v41,
                      v42,
                      v43,
                      v44,
                      v45,
                      v8,
                      v46,
                      v47,
                      v48
                    ]
                  },
                  v49,
                  v50,
                  v51,
                  v52,
                  v53,
                  v54,
                  v55,
                  v56,
                  v57,
                  v58
                ]
              },
              v59
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "InvestmentOptionsGridQuery",
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "fundAccountsForInstitution",
            "storageKey": null,
            "args": v1,
            "concreteType": "FundAccount",
            "plural": true,
            "selections": [
              v2,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "account",
                "storageKey": null,
                "args": null,
                "concreteType": "Account",
                "plural": false,
                "selections": [
                  v3,
                  v4,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "division",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Division",
                    "plural": false,
                    "selections": v60
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "client",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "ClientType",
                    "plural": false,
                    "selections": v60
                  },
                  v6,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "tradeInstitution",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "InstitutionLocation",
                    "plural": false,
                    "selections": [
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "location",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Location",
                        "plural": false,
                        "selections": v60
                      },
                      {
                        "kind": "LinkedField",
                        "alias": null,
                        "name": "institution",
                        "storageKey": null,
                        "args": null,
                        "concreteType": "Institution",
                        "plural": false,
                        "selections": v60
                      },
                      v2
                    ]
                  },
                  v2
                ]
              },
              v9,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "fund",
                "storageKey": null,
                "args": null,
                "concreteType": "Fund",
                "plural": false,
                "selections": [
                  v10,
                  v2,
                  v11,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "provider",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Provider",
                    "plural": false,
                    "selections": v60
                  },
                  v4,
                  v12,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "fundCategory",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "FundSubCategory",
                    "plural": false,
                    "selections": v60
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "fundSubCategory",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "FundCategory",
                    "plural": false,
                    "selections": v60
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "currency",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Currency",
                    "plural": false,
                    "selections": [
                      v7,
                      v2
                    ]
                  },
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "domicileCountry",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "DomicileCountry",
                    "plural": false,
                    "selections": v60
                  },
                  v13,
                  v14,
                  v15,
                  v16,
                  v17,
                  v18,
                  v19,
                  v20,
                  v21,
                  v22,
                  v23,
                  v24,
                  v25,
                  v26,
                  v27,
                  v28,
                  v29,
                  v30,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "statistics",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Statistics",
                    "plural": false,
                    "selections": [
                      v41,
                      v32,
                      v33,
                      v34,
                      v35,
                      v36,
                      v37,
                      v38,
                      v39,
                      v31,
                      v40,
                      v42,
                      v43,
                      v44,
                      v45,
                      v8,
                      v46,
                      v47,
                      v48,
                      v2
                    ]
                  },
                  v49,
                  v50,
                  v51,
                  v52,
                  v53,
                  v54,
                  v55,
                  v56,
                  v57,
                  v58
                ]
              },
              v59
            ]
          },
          v2
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = '5719f1a72a37abcf410b5c87a2960ad6';
module.exports = node;
