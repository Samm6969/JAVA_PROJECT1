export const UPDATE_USER_SETTINGS = 'UPDATE_USER_SETTINGS'

export const updateUserSettingsAction = settings => ({
  type: UPDATE_USER_SETTINGS,
  settings,
})
