/**
 * @flow
 * @relayHash 0c7aa44a513e4537061922f29031c412
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type OrderQtyTypeEnum = "CURRENCY" | "SHARES" | "%future added value";
export type OrderSideEnum = "BUY" | "CREATE" | "DIVIDEND_CASH" | "DIVIDEND_NOT_SUPPORTED" | "DIVIDEND_OTHER" | "DIVIDEND_REDUCTION" | "DIVIDEND_REINVEST" | "REDEEM" | "SELL" | "UNKNOWN" | "%future added value";
export type OrderStatusEnum = "ACCEPTED" | "APPRV_DENIED" | "APPRV_REQ" | "CANCELLED" | "COMPLETED" | "CREATED" | "IN_PROGRESS" | "PENDING_FUTURE" | "PENDING_REVIEW" | "REJECTED" | "SUBMITTED" | "VOIDED" | "%future added value";
export type TradeBlotterGridQueryVariables = {||};
export type TradeBlotterGridQueryResponse = {|
  +viewer: ?{|
    +recentOrders: ?$ReadOnlyArray<?{|
      +id: string,
      +orderStatus: ?OrderStatusEnum,
      +orderId: ?number,
      +submitDate: ?string,
      +tradeDate: ?string,
      +fundAccount: ?{|
        +fund: ?{|
          +id: string,
          +name: ?string,
        |},
        +account: ?{|
          +name: ?string
        |},
      |},
      +investorUid: ?string,
      +side: ?OrderSideEnum,
      +quantity: ?number,
      +qtyDecimals: ?number,
      +currency: ?{|
        +currencyCode: ?string
      |},
      +qtyType: ?OrderQtyTypeEnum,
      +settlementDate: ?string,
      +cashSettlementStatus: ?string,
      +custodySettlementStatus: ?string,
    |}>
  |}
|};
export type TradeBlotterGridQuery = {|
  variables: TradeBlotterGridQueryVariables,
  response: TradeBlotterGridQueryResponse,
|};
*/


/*
query TradeBlotterGridQuery {
  viewer {
    recentOrders {
      id
      orderStatus
      orderId
      submitDate
      tradeDate
      fundAccount {
        fund {
          id
          name
        }
        account {
          name
          id
        }
        id
      }
      investorUid
      side
      quantity
      qtyDecimals
      currency {
        currencyCode
        id
      }
      qtyType
      settlementDate
      cashSettlementStatus
      custodySettlementStatus
    }
    id
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "side",
  "args": null,
  "storageKey": null
},
v1 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderId",
  "args": null,
  "storageKey": null
},
v3 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "submitDate",
  "args": null,
  "storageKey": null
},
v4 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "tradeDate",
  "args": null,
  "storageKey": null
},
v5 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "name",
  "args": null,
  "storageKey": null
},
v6 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "fund",
  "storageKey": null,
  "args": null,
  "concreteType": "Fund",
  "plural": false,
  "selections": [
    v1,
    v5
  ]
},
v7 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "investorUid",
  "args": null,
  "storageKey": null
},
v8 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderStatus",
  "args": null,
  "storageKey": null
},
v9 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "quantity",
  "args": null,
  "storageKey": null
},
v10 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "qtyDecimals",
  "args": null,
  "storageKey": null
},
v11 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "currencyCode",
  "args": null,
  "storageKey": null
},
v12 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "qtyType",
  "args": null,
  "storageKey": null
},
v13 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "settlementDate",
  "args": null,
  "storageKey": null
},
v14 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "cashSettlementStatus",
  "args": null,
  "storageKey": null
},
v15 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodySettlementStatus",
  "args": null,
  "storageKey": null
};
return {
  "kind": "Request",
  "operationKind": "query",
  "name": "TradeBlotterGridQuery",
  "id": null,
  "text": "query TradeBlotterGridQuery {\n  viewer {\n    recentOrders {\n      id\n      orderStatus\n      orderId\n      submitDate\n      tradeDate\n      fundAccount {\n        fund {\n          id\n          name\n        }\n        account {\n          name\n          id\n        }\n        id\n      }\n      investorUid\n      side\n      quantity\n      qtyDecimals\n      currency {\n        currencyCode\n        id\n      }\n      qtyType\n      settlementDate\n      cashSettlementStatus\n      custodySettlementStatus\n    }\n    id\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "TradeBlotterGridQuery",
    "type": "Root",
    "metadata": null,
    "argumentDefinitions": [],
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "recentOrders",
            "storageKey": null,
            "args": null,
            "concreteType": "Order",
            "plural": true,
            "selections": [
              v0,
              v1,
              v2,
              v3,
              v4,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "fundAccount",
                "storageKey": null,
                "args": null,
                "concreteType": "FundAccount",
                "plural": false,
                "selections": [
                  v6,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "account",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Account",
                    "plural": false,
                    "selections": [
                      v5
                    ]
                  }
                ]
              },
              v7,
              v8,
              v9,
              v10,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "currency",
                "storageKey": null,
                "args": null,
                "concreteType": "Currency",
                "plural": false,
                "selections": [
                  v11
                ]
              },
              v12,
              v13,
              v14,
              v15
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "TradeBlotterGridQuery",
    "argumentDefinitions": [],
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "recentOrders",
            "storageKey": null,
            "args": null,
            "concreteType": "Order",
            "plural": true,
            "selections": [
              v0,
              v1,
              v2,
              v3,
              v4,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "fundAccount",
                "storageKey": null,
                "args": null,
                "concreteType": "FundAccount",
                "plural": false,
                "selections": [
                  v6,
                  {
                    "kind": "LinkedField",
                    "alias": null,
                    "name": "account",
                    "storageKey": null,
                    "args": null,
                    "concreteType": "Account",
                    "plural": false,
                    "selections": [
                      v5,
                      v1
                    ]
                  },
                  v1
                ]
              },
              v7,
              v8,
              v9,
              v10,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "currency",
                "storageKey": null,
                "args": null,
                "concreteType": "Currency",
                "plural": false,
                "selections": [
                  v11,
                  v1
                ]
              },
              v12,
              v13,
              v14,
              v15
            ]
          },
          v1
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = '9c5ea82dabbf1d0cbe09143e9946a1f7';
module.exports = node;
