import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { LoadingIndicator } from '@fc/react-playbook'
import { graphql } from 'react-relay'
// import _ from 'lodash'

import withQueryRenderer from '../../hoc/withQueryRenderer'
import ValueField from '../../components/ValueField'
import TableOfContentsChapter from '../../components/TableOfContents/TableOfContentsChapter'

const query = graphql`
  query FundDetailsQuery($id: ID!) {
    node(id: $id) {
      ... on Fund {
        fundId
        name
      }
    }
  }
`
@withQueryRenderer({
  query,
})
class FundDetails extends Component {
  static propTypes = {
    // eslint-disable-next-line react/no-unused-prop-types
    variables: PropTypes.shape({
      id: PropTypes.string.isRequired,
    }).isRequired,
    node: PropTypes.shape({
      name: PropTypes.string.isRequired,
      fundId: PropTypes.string.isRequired,
    }),
    isLoading: PropTypes.bool,
  }

  render() {
    const { isLoading, node } = this.props
    if (isLoading) {
      return (
        <div>
          <LoadingIndicator />
        </div>
      )
    }
    const { name, fundId } = node
    return (
      <div>
        {name}
        <TableOfContentsChapter name="Details">
          <div>
            <ValueField value={name} label="Fund Short Name" inline />
            <ValueField value={fundId} label="Fund ID" inline />
          </div>
        </TableOfContentsChapter>
      </div>
    )
  }
}

export default FundDetails
