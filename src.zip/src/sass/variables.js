import { prepareSASSVariables } from '@fc/react-playbook'
import variables from './_variables.scss'

export default prepareSASSVariables(variables)
