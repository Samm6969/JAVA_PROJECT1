export default [
  {
    exact: true,
    to: '/',
    label: 'Dashboard',
  },
  {
    to: '/portfolio',
    label: 'Portfolio',
  },
  {
    to: '/funds/search',
    label: 'Search Funds',
  },
  {
    group: 'Trade',
    to: '/trade',
    collapsible: true,
    items: [
      {
        to: '/direct/short-term',
        label: 'Short Term Funds',
      },
      {
        to: '/direct/long-term',
        label: 'Long Term Funds',
      },
      {
        to: '/etf',
        label: 'ETFs',
      },
      {
        to: '/bloomberg-bskt',
        label: 'Bloomberg BSKT',
      },
      {
        to: '/agent-fund-trading',
        label: 'Agent Fund Trading',
      },
      {
        to: '/non-direct/short-term',
        label: 'Non-Direct',
      },
      {
        to: '/blotter',
        label: 'Trade Blotter',
      },
    ],
  },
  {
    group: 'Reports',
    to: '/reports',
    collapsible: true,
    items: [
      {
        to: '/trade-activity',
        label: 'Trade Activity',
      },
      {
        to: '/daily-investment-detail',
        label: 'Daily Investment Detail',
      },
      {
        to: '/daily-investment-summary',
        label: 'Daily Investment Summary',
      },
      {
        to: '/fund-statistics',
        label: 'Fund Statistics',
      },
      {
        to: '/intraday-prices',
        label: 'Intraday Prices',
      },
      {
        to: '/holdings-report',
        label: 'Holdings Report',
      },
      {
        to: '/account-summary',
        label: 'Account Summary',
      },
    ],
  },
  {
    group: 'Transparency',
    to: '/transparency',
    collapsible: true,
    items: [
      {
        to: '/details',
        label: 'Details',
      },
      {
        to: '/chart',
        label: 'Chart',
      },
      {
        to: '/virtual-portfolio',
        label: 'Virtual Portfolio',
      },
    ],
  },
  {
    group: 'Administration',
    to: '/admin',
    collapsible: true,
    items: [
      {
        to: '/preferences',
        label: 'Preferences',
      },
      {
        to: '/limits',
        label: 'Limits',
        items: [
          {
            to: '/order-limits',
            label: 'Investor Order Limits',
          },
          {
            to: '/fund-limits',
            label: 'Fund Limits',
          },
        ],
      },
      {
        to: '/notifications',
        label: 'Notifications',
        items: [
          {
            to: '/status',
            label: 'Status Table Styled',
          },
          {
            to: '/status-accordian',
            label: 'Status Accordian Styled',
          },
          {
            to: '/status-workflow',
            label: 'Status Cards Styled',
          },
          {
            to: '/status-cards',
            label: 'Status section styled',
          },
          {
            to: '/status-section',
            label: 'Status section styled',
          },
          /*  {
            to: '/fund',
            label: 'Fund Status Notifications',
          }, */
        ],
      },
    ],
  },
]
