import { createFragmentContainer } from 'react-relay'

const withFragmentContainer = fragmentSpec => component =>
  createFragmentContainer(component, fragmentSpec)

export default withFragmentContainer
