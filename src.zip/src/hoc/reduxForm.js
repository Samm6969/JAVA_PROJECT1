import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { reduxForm as reactReduxForm, change as changeAction } from 'redux-form'
import _ from 'lodash'
import { connect } from 'react-redux'

export const {
  Provider: ReduxFormProvider,
  Consumer: ReduxFormConsumer,
} = React.createContext({})

const mapDispatchToProps = dispatch => ({
  setFormValue: (...args) => dispatch(changeAction(...args)),
})

const reduxForm = options => WrappedComponent => {
  const ReduxFormComponent = reactReduxForm({
    enableReinitialize: true,
    ...options,
  })(WrappedComponent)

  @connect(
    null,
    mapDispatchToProps,
  )
  class ReduxForm extends Component {
    static propTypes = {
      setFormValue: PropTypes.func.isRequired,
    }

    state = {
      defaultValues: new Map(),
    }

    setInitialValue = (member, value) => {
      const { setFormValue, form } = this.props
      const { defaultValues } = this.state
      const formName = form || options.form

      defaultValues.set(member, value)
      this.setState(
        {
          defaultValues,
        },
        () => {
          setFormValue(formName, member, value)
        },
      )
    }

    get initialValues() {
      const { initialValues: initialValuesProps } = this.props
      const initialValues = initialValuesProps || options.initialValues

      if (!initialValues) {
        return undefined
      }

      const { defaultValues } = this.state
      defaultValues.forEach((value, member) => {
        _.set(initialValues, member, value)
      })

      return initialValues
    }

    render() {
      return (
        <ReduxFormProvider
          value={{
            setInitialValue: this.setInitialValue,
          }}
        >
          <ReduxFormComponent
            {...this.props}
            initialValues={this.initialValues}
          />
        </ReduxFormProvider>
      )
    }
  }

  return ReduxForm
}

export default reduxForm
