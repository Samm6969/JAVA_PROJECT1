import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { QueryRenderer } from 'react-relay'
import defaultEnvironment from '../environment'

const withQueryRenderer = ({
  cacheConfig: cacheConfigHOC,
  environment: environmentHOC,
  query: queryHOC,
  render: renderHOC,
  variables: variablesHOC,
  defer: deferHOC,
}) => ComposedComponent =>
  class extends Component {
    static propTypes = {
      // eslint-disable-next-line react/forbid-prop-types
      cacheConfig: PropTypes.object,
      // eslint-disable-next-line react/forbid-prop-types
      environment: PropTypes.object,
      query: PropTypes.func,
      render: PropTypes.func,
      variables: PropTypes.oneOfType([PropTypes.object, PropTypes.func]),
      // eslint-disable-next-line react/forbid-foreign-prop-types
      ...ComposedComponent.propTypes,
    }

    static defaultProps = {
      environment: defaultEnvironment,
    }

    state = {
      hasError: false,
    }

    componentDidCatch(error, info) {
      /* TODO log error/info objects on the server somewhere when in non-dev mode */
      this.setState({ hasError: true })
      // eslint-disable-next-line no-console
      console.error(error, info)
    }

    render() {
      const {
        cacheConfig,
        environment,
        query,
        render,
        variables: propVariables,
        ...rest
      } = this.props

      const { hasError } = this.state

      if (hasError) {
        return null
      }

      const variables = propVariables || variablesHOC
      const qrVariables =
        typeof variables === 'function' ? variables(this.props) : variables

      const defaultRenderer = ({ error, props }) => {
        if (error) {
          return <div>{error.message}</div>
        }
        if (props) {
          return (
            <ComposedComponent
              isLoading={false}
              {...rest}
              {...props}
              variables={qrVariables}
            />
          )
        }
        return <ComposedComponent isLoading {...rest} variables={qrVariables} />
      }

      const defer =
        typeof deferHOC === 'function'
          ? deferHOC(qrVariables, this.props)
          : false

      if (defer) {
        return null
      }

      return (
        <QueryRenderer
          cacheConfig={cacheConfig || cacheConfigHOC}
          environment={environment || environmentHOC}
          query={query || queryHOC}
          variables={qrVariables}
          render={render || renderHOC || defaultRenderer}
        />
      )
    }
  }

export default withQueryRenderer
