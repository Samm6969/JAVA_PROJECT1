import { Environment, Network, RecordSource, Store } from 'relay-runtime'
import axios from 'axios'

const source = new RecordSource()
const store = new Store(source)

const fetchQuery = async (operation, variables) => {
  const url = `${process.env.API_ENDPOINT}`
  try {
    const response = await axios({
      url,
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      method: 'POST',
      data: JSON.stringify({
        query: operation.text, // GraphQL text from input
        variables,
      }),
    })
    return response.data
  } catch (error) {
    /* eslint-disable no-console */
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      console.log(error.response.data)
      console.log(error.response.status)
      console.log(error.response.headers)
    } else if (error.request) {
      // The request was made but no response was received
      // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
      // http.ClientRequest in node.js
      console.log(error.request)
    } else {
      // Something happened in setting up the request that triggered an Error
      console.error(error.message)
    }
    console.log(error.config)
    /* eslint-enable no-console */
  }

  return null
}

const network = Network.create(fetchQuery) // see note below

export default new Environment({
  network,
  store,
})
