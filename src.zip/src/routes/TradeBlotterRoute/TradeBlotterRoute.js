import React from 'react'

import TradeBlotter from '../../containers/TradeBlotter'

// TODO: Explore what props this component should accept
const TradeBlotterRoute = props => <TradeBlotter {...props} />

export default TradeBlotterRoute
