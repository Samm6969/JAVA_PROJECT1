import React from 'react'
import { Legal, ScrollContainer, Support } from '@fc/react-playbook'
import { ACCOUNT_TYPES, FUND_TYPES } from '../enums'

import OrderEntryRoute from './OrderEntryRoute'
import OrderConfirmRoute from './OrderConfirmRoute'
import DashboardRoute from './DashboardRoute'
import FundDetailsRoute from './FundDetailsRoute'
import InvestmentOptionsRoute from './InvestmentOptionsRoute'
import SearchFundsRoute from './SearchFundsRoute'
import BloombergBSKTRoute from './BloombergBSKTRoute'
import TradeBlotterRoute from './TradeBlotterRoute'
import AgentFundTradingRoute from './AgentFundTradingRoute'

const orderEntry = [
  {
    path: '/order-entry',
    title: 'Order Entry',
    component: OrderEntryRoute,
  },
  {
    path: '/order-confirm',
    title: 'Order Confirmation',
    component: OrderConfirmRoute,
  },
]

export default [
  {
    path: '/',
    title: 'Dashboard',
    component: DashboardRoute,
  },
  {
    path: '/funds/search',
    title: 'Search Funds',
    component: SearchFundsRoute({
      title: 'Search Short Term Funds',
      fundType: FUND_TYPES.SHORT_TERM,
      accountType: ACCOUNT_TYPES.FULLY_DISCLOSED,
    }),
  },
  {
    path: '/trade/direct/short-term',
    title: 'Investment Options',
    component: InvestmentOptionsRoute({
      title: 'Short Term Funds',
      fundType: FUND_TYPES.SHORT_TERM,
      accountType: ACCOUNT_TYPES.FULLY_DISCLOSED,
    }),
    routes: [...orderEntry],
  },
  {
    path: '/trade/direct/long-term',
    title: 'Investment Options',
    component: InvestmentOptionsRoute({
      title: 'Long Term Funds',
      fundType: FUND_TYPES.LONG_TERM,
      accountType: ACCOUNT_TYPES.FULLY_DISCLOSED,
    }),
    routes: [...orderEntry],
  },
  {
    path: '/trade/non-direct/short-term',
    title: 'Investment Options',
    component: InvestmentOptionsRoute({
      title: 'Non-Direct',
      fundType: FUND_TYPES.SHORT_TERM,
      accountType: ACCOUNT_TYPES.OMNI,
    }),
    routes: [...orderEntry],
  },
  {
    path: '/trade/agent-fund-trading',
    title: 'Agent Fund Trading | Enter Order',
    component: AgentFundTradingRoute({
      title: 'Agent Fund Trading',
    }),
  },
  {
    path: '/trade/blotter',
    title: 'Trade Blotter',
    component: TradeBlotterRoute,
  },
  {
    path: '/trade/bloomberg-bskt',
    title: 'Bloomberg BSKT',
    component: BloombergBSKTRoute,
  },
  {
    path: '/fund-details/:id',
    title: 'Fund Details',
    component: FundDetailsRoute,
    routes: [...orderEntry],
  },
  {
    path: '/legal',
    title: 'Legal',
    component: () => (
      <ScrollContainer>
        <Legal />
      </ScrollContainer>
    ),
  },
  {
    path: '/support',
    title: 'Support',
    component: () => (
      <ScrollContainer>
        <Support />
      </ScrollContainer>
    ),
  },
]
