/**
 * @flow
 * @relayHash 0b7d965c58a281cb02bed451275179e3
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type OrderQtyTypeEnum = "CURRENCY" | "SHARES" | "%future added value";
export type OrderSideEnum = "BUY" | "CREATE" | "DIVIDEND_CASH" | "DIVIDEND_NOT_SUPPORTED" | "DIVIDEND_OTHER" | "DIVIDEND_REDUCTION" | "DIVIDEND_REINVEST" | "REDEEM" | "SELL" | "UNKNOWN" | "%future added value";
export type OrderStatusEnum = "ACCEPTED" | "APPRV_DENIED" | "APPRV_REQ" | "CANCELLED" | "COMPLETED" | "CREATED" | "IN_PROGRESS" | "PENDING_FUTURE" | "PENDING_REVIEW" | "REJECTED" | "SUBMITTED" | "VOIDED" | "%future added value";
export type RedemptionFeeTypeEnum = "GROSS" | "NET" | "%future added value";
export type OrderRequestsInput = {
  clientMutationId?: ?string,
  orderRequests?: ?$ReadOnlyArray<?OrderRequestInput>,
};
export type OrderRequestInput = {
  fundAccountId: string,
  side?: ?OrderSideEnum,
  qtyType?: ?OrderQtyTypeEnum,
  quantity?: ?number,
  tradeDate?: ?string,
  redemptionFeeType?: ?RedemptionFeeTypeEnum,
  overriddenSettlementPeriod?: ?number,
  userTradeWindowId?: ?number,
  investorCashSettlementInstruction?: ?number,
  investorCustodySettlementInstruction?: ?number,
  investorPaymentInstruction?: ?number,
  comments?: ?string,
  approvalMessage?: ?string,
};
export type OrderConfirmRouteMutationVariables = {|
  input: OrderRequestsInput
|};
export type OrderConfirmRouteMutationResponse = {|
  +confirmOrders: ?{|
    +id: string,
    +orderResponsesId: ?string,
    +orderResponses: ?$ReadOnlyArray<?{|
      +orderId: ?number,
      +orderStatus: ?OrderStatusEnum,
    |}>,
  |}
|};
export type OrderConfirmRouteMutation = {|
  variables: OrderConfirmRouteMutationVariables,
  response: OrderConfirmRouteMutationResponse,
|};
*/


/*
mutation OrderConfirmRouteMutation(
  $input: OrderRequestsInput!
) {
  confirmOrders(input: $input) {
    id
    orderResponsesId
    orderResponses {
      orderId
      orderStatus
      id
    }
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = [
  {
    "kind": "LocalArgument",
    "name": "input",
    "type": "OrderRequestsInput!",
    "defaultValue": null
  }
],
v1 = [
  {
    "kind": "Variable",
    "name": "input",
    "variableName": "input",
    "type": "OrderRequestsInput!"
  }
],
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v3 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderResponsesId",
  "args": null,
  "storageKey": null
},
v4 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderId",
  "args": null,
  "storageKey": null
},
v5 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "orderStatus",
  "args": null,
  "storageKey": null
};
return {
  "kind": "Request",
  "operationKind": "mutation",
  "name": "OrderConfirmRouteMutation",
  "id": null,
  "text": "mutation OrderConfirmRouteMutation(\n  $input: OrderRequestsInput!\n) {\n  confirmOrders(input: $input) {\n    id\n    orderResponsesId\n    orderResponses {\n      orderId\n      orderStatus\n      id\n    }\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "OrderConfirmRouteMutation",
    "type": "Mutation",
    "metadata": null,
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "confirmOrders",
        "storageKey": null,
        "args": v1,
        "concreteType": "OrderResponses",
        "plural": false,
        "selections": [
          v2,
          v3,
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "orderResponses",
            "storageKey": null,
            "args": null,
            "concreteType": "OrderResponse",
            "plural": true,
            "selections": [
              v4,
              v5
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "OrderConfirmRouteMutation",
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "confirmOrders",
        "storageKey": null,
        "args": v1,
        "concreteType": "OrderResponses",
        "plural": false,
        "selections": [
          v2,
          v3,
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "orderResponses",
            "storageKey": null,
            "args": null,
            "concreteType": "OrderResponse",
            "plural": true,
            "selections": [
              v4,
              v5,
              v2
            ]
          }
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = '974c3d271f0080664bdbee89aa9a76e4';
module.exports = node;
