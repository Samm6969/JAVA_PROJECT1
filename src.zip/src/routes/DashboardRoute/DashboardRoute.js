import React, { Component } from 'react'

class DashboardRoute extends Component {
  render() {
    return <div />
  }
}

export default DashboardRoute
