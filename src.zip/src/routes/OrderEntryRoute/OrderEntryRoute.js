import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import _ from 'lodash'
import {
  reset as resetAction,
  change as changeAction,
  submit as submitAction,
  untouch as untouchAction,
} from 'redux-form'
import {
  FillContainer,
  Card,
  CardContent,
  CardFooter,
  Button,
  LoadingIndicator,
  // ScrollContainer,
} from '@fc/react-playbook'
import { graphql } from 'react-relay'
// import _ from 'lodash'
import withQueryRenderer from '../../hoc/withQueryRenderer'
import { OrderEntryProvider } from './OrderEntryRouteContext'
import MMFOrderEntryForm from '../../containers/MMFOrderEntryForm'
// import commitMutation from '../../utils/commitMutation'

import s from './OrderEntryRoute.scss'
import { getLongAccount } from '../../utils/Stringify'

const query = graphql`
  query OrderEntryRouteQuery($fundAccountIds: [ID]) {
    viewer {
      fundAccountsByIds(fundAccountIds: $fundAccountIds) {
        id
        fundAccountId
        supportedQtyTypes {
          buy
          sell
        }
        cashInstructions {
          id
          displayName
          custodianName
          custodianAccount
          custodianBIC
          cashCutoffTimeDisplay
          cashInstructionId
          defaultCurrencySSI
          cashBuyMsgType
        }
        custodyInstructions {
          id
          displayName
          custodianName
          custodianAccount
          custodianBIC
          custodyInstructionId
          defaultCurrencySSI
          custodyBuyMsgType
          includeCashParties
        }
      }
    }
  }
`

const mapDispatchToProps = dispatch => ({
  reset: id => dispatch(resetAction(id)),
  submit: id => dispatch(submitAction(id)),
  untouch: (...args) => dispatch(untouchAction(args)),
  setFormValue: (...args) => dispatch(changeAction(...args)),
})

@connect(
  null,
  mapDispatchToProps,
)
@withQueryRenderer({
  query,
  variables: props => {
    const { location } = props
    const fundAccountIds =
      typeof location.state !== 'undefined' &&
      typeof location.state.fundAccountIds !== 'undefined'
        ? location.state.fundAccountIds
        : []

    return {
      fundAccountIds,
    }
  },
})
class OrderEntryRoute extends Component {
  static propTypes = {
    isLoading: PropTypes.bool,
    history: PropTypes.shape({
      goBack: PropTypes.func.isRequired,
    }).isRequired,
    reset: PropTypes.func.isRequired,
    submit: PropTypes.func.isRequired,
    // untouch: PropTypes.func.isRequired,
    setFormValue: PropTypes.func.isRequired,
    viewer: PropTypes.shape({
      fundAccountsByIds: PropTypes.arrayOf(
        PropTypes.shape({
          id: PropTypes.string.isRequired,
        }),
      ),
    }),
    location: PropTypes.shape({
      state: PropTypes.shape({
        selected: PropTypes.arrayOf(PropTypes.object),
      }),
    }),
  }

  state = {
    defaultSettlementInstructions: new Map(),
    selectedOrdersByPath: [],
  }

  formName = 'MMFOrderEntryForm'

  get initialValues() {
    const { location } = this.props
    const selected =
      typeof location.state !== 'undefined' &&
      typeof location.state.selected !== 'undefined'
        ? location.state.selected
        : []

    const initialValues = selected.map(({ accounts, ...rest }) => ({
      ...rest,
      accounts: _.sortBy(accounts, account => getLongAccount(account.account)),
    }))

    return {
      selected: initialValues,
    }
  }

  onOrderSelectionChange = (event, newValue, previousValue, name) => {
    const { selectedOrdersByPath } = this.state
    const accountMember = name.replace('selectedForTrade', '')
    if (newValue) {
      selectedOrdersByPath.push(accountMember)
      this.setState({
        selectedOrdersByPath,
      })
    } else {
      // Mutates the original array
      _.remove(selectedOrdersByPath, member => member === accountMember)
      this.setState({
        selectedOrdersByPath,
      })
    }
  }

  setDefaultSSI = (add, field, value) => {
    this.setState(state => {
      const { defaultSettlementInstructions } = state
      const hasField = defaultSettlementInstructions.has(field)

      if (!hasField && add) {
        defaultSettlementInstructions.set(field, value)
        return {
          defaultSettlementInstructions,
        }
      }

      if (hasField && !add) {
        defaultSettlementInstructions.delete(field)
        return {
          defaultSettlementInstructions,
        }
      }

      return null
    })
  }

  handleSubmit = () => {
    const { submit } = this.props
    if (typeof submit === 'function') {
      submit(this.formName)
    }
  }

  handleCancel = () => {
    const { history } = this.props
    history.goBack()
  }

  handleReset = () => {
    const { reset } = this.props
    reset(this.formName)
    this.setState({
      selectedOrdersByPath: [],
    })
  }

  handleDefaultSettlementInstructions = () => {
    const { setFormValue } = this.props
    const { defaultSettlementInstructions } = this.state
    defaultSettlementInstructions.forEach((value, field) => {
      setFormValue(this.formName, field, value)
    })
  }

  render() {
    const { isLoading, viewer, location } = this.props
    const { selectedOrdersByPath, defaultSettlementInstructions } = this.state
    const disabled = selectedOrdersByPath.length === 0

    return (
      <FillContainer>
        <Card className={s.card}>
          <CardContent>
            {isLoading && <LoadingIndicator />}
            {!isLoading && (
              <OrderEntryProvider
                value={{
                  fundAccountsByIds: viewer.fundAccountsByIds,
                  onOrderSelectionChange: this.onOrderSelectionChange,
                  setDefaultSSI: this.setDefaultSSI,
                  accountType: location.state.accountType,
                }}
              >
                <MMFOrderEntryForm
                  form={this.formName}
                  suppressHydrationWarning
                  initialValues={this.initialValues}
                  selectedOrdersByPath={selectedOrdersByPath}
                  enableReinitialize
                />
              </OrderEntryProvider>
            )}
          </CardContent>
          <CardFooter flexEnd>
            <Button onClick={this.handleCancel}>Cancel</Button>
            <Button disabled={disabled} onClick={this.handleReset}>
              Clear Form
            </Button>
            <Button
              disabled={defaultSettlementInstructions.size === 0}
              onClick={this.handleDefaultSettlementInstructions}
            >
              Default Settlement Instructions
            </Button>
            <Button
              primary
              type="submit"
              disabled={disabled}
              onClick={this.handleSubmit}
            >
              Enter Orders {!disabled && `(${selectedOrdersByPath.length})`}
            </Button>
          </CardFooter>
        </Card>
      </FillContainer>
    )
  }
}

export default OrderEntryRoute
