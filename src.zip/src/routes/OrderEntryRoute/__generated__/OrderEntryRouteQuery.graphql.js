/**
 * @flow
 * @relayHash 849d2c43c74f89acde0e3dc67e972215
 */

/* eslint-disable */

'use strict';

/*::
import type { ConcreteRequest } from 'relay-runtime';
export type OrderEntryRouteQueryVariables = {|
  fundAccountIds?: ?$ReadOnlyArray<?string>
|};
export type OrderEntryRouteQueryResponse = {|
  +viewer: ?{|
    +fundAccountsByIds: ?$ReadOnlyArray<?{|
      +id: string,
      +fundAccountId: ?string,
      +supportedQtyTypes: ?{|
        +buy: ?$ReadOnlyArray<?string>,
        +sell: ?$ReadOnlyArray<?string>,
      |},
      +cashInstructions: ?$ReadOnlyArray<?{|
        +id: string,
        +displayName: ?string,
        +custodianName: ?string,
        +custodianAccount: ?string,
        +custodianBIC: ?string,
        +cashCutoffTimeDisplay: ?string,
        +cashInstructionId: ?string,
        +defaultCurrencySSI: ?boolean,
        +cashBuyMsgType: ?string,
      |}>,
      +custodyInstructions: ?$ReadOnlyArray<?{|
        +id: string,
        +displayName: ?string,
        +custodianName: ?string,
        +custodianAccount: ?string,
        +custodianBIC: ?string,
        +custodyInstructionId: ?string,
        +defaultCurrencySSI: ?boolean,
        +custodyBuyMsgType: ?string,
        +includeCashParties: ?boolean,
      |}>,
    |}>
  |}
|};
export type OrderEntryRouteQuery = {|
  variables: OrderEntryRouteQueryVariables,
  response: OrderEntryRouteQueryResponse,
|};
*/


/*
query OrderEntryRouteQuery(
  $fundAccountIds: [ID]
) {
  viewer {
    fundAccountsByIds(fundAccountIds: $fundAccountIds) {
      id
      fundAccountId
      supportedQtyTypes {
        buy
        sell
        id
      }
      cashInstructions {
        id
        displayName
        custodianName
        custodianAccount
        custodianBIC
        cashCutoffTimeDisplay
        cashInstructionId
        defaultCurrencySSI
        cashBuyMsgType
      }
      custodyInstructions {
        id
        displayName
        custodianName
        custodianAccount
        custodianBIC
        custodyInstructionId
        defaultCurrencySSI
        custodyBuyMsgType
        includeCashParties
      }
    }
    id
  }
}
*/

const node/*: ConcreteRequest*/ = (function(){
var v0 = [
  {
    "kind": "LocalArgument",
    "name": "fundAccountIds",
    "type": "[ID]",
    "defaultValue": null
  }
],
v1 = [
  {
    "kind": "Variable",
    "name": "fundAccountIds",
    "variableName": "fundAccountIds",
    "type": "[ID]"
  }
],
v2 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "id",
  "args": null,
  "storageKey": null
},
v3 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "fundAccountId",
  "args": null,
  "storageKey": null
},
v4 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "buy",
  "args": null,
  "storageKey": null
},
v5 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "sell",
  "args": null,
  "storageKey": null
},
v6 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "displayName",
  "args": null,
  "storageKey": null
},
v7 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodianName",
  "args": null,
  "storageKey": null
},
v8 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodianAccount",
  "args": null,
  "storageKey": null
},
v9 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "custodianBIC",
  "args": null,
  "storageKey": null
},
v10 = {
  "kind": "ScalarField",
  "alias": null,
  "name": "defaultCurrencySSI",
  "args": null,
  "storageKey": null
},
v11 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "cashInstructions",
  "storageKey": null,
  "args": null,
  "concreteType": "CashInstruction",
  "plural": true,
  "selections": [
    v2,
    v6,
    v7,
    v8,
    v9,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "cashCutoffTimeDisplay",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "cashInstructionId",
      "args": null,
      "storageKey": null
    },
    v10,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "cashBuyMsgType",
      "args": null,
      "storageKey": null
    }
  ]
},
v12 = {
  "kind": "LinkedField",
  "alias": null,
  "name": "custodyInstructions",
  "storageKey": null,
  "args": null,
  "concreteType": "CustodyInstruction",
  "plural": true,
  "selections": [
    v2,
    v6,
    v7,
    v8,
    v9,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "custodyInstructionId",
      "args": null,
      "storageKey": null
    },
    v10,
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "custodyBuyMsgType",
      "args": null,
      "storageKey": null
    },
    {
      "kind": "ScalarField",
      "alias": null,
      "name": "includeCashParties",
      "args": null,
      "storageKey": null
    }
  ]
};
return {
  "kind": "Request",
  "operationKind": "query",
  "name": "OrderEntryRouteQuery",
  "id": null,
  "text": "query OrderEntryRouteQuery(\n  $fundAccountIds: [ID]\n) {\n  viewer {\n    fundAccountsByIds(fundAccountIds: $fundAccountIds) {\n      id\n      fundAccountId\n      supportedQtyTypes {\n        buy\n        sell\n        id\n      }\n      cashInstructions {\n        id\n        displayName\n        custodianName\n        custodianAccount\n        custodianBIC\n        cashCutoffTimeDisplay\n        cashInstructionId\n        defaultCurrencySSI\n        cashBuyMsgType\n      }\n      custodyInstructions {\n        id\n        displayName\n        custodianName\n        custodianAccount\n        custodianBIC\n        custodyInstructionId\n        defaultCurrencySSI\n        custodyBuyMsgType\n        includeCashParties\n      }\n    }\n    id\n  }\n}\n",
  "metadata": {},
  "fragment": {
    "kind": "Fragment",
    "name": "OrderEntryRouteQuery",
    "type": "Root",
    "metadata": null,
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "fundAccountsByIds",
            "storageKey": null,
            "args": v1,
            "concreteType": "FundAccount",
            "plural": true,
            "selections": [
              v2,
              v3,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "supportedQtyTypes",
                "storageKey": null,
                "args": null,
                "concreteType": "QtyTypes",
                "plural": false,
                "selections": [
                  v4,
                  v5
                ]
              },
              v11,
              v12
            ]
          }
        ]
      }
    ]
  },
  "operation": {
    "kind": "Operation",
    "name": "OrderEntryRouteQuery",
    "argumentDefinitions": v0,
    "selections": [
      {
        "kind": "LinkedField",
        "alias": null,
        "name": "viewer",
        "storageKey": null,
        "args": null,
        "concreteType": "Viewer",
        "plural": false,
        "selections": [
          {
            "kind": "LinkedField",
            "alias": null,
            "name": "fundAccountsByIds",
            "storageKey": null,
            "args": v1,
            "concreteType": "FundAccount",
            "plural": true,
            "selections": [
              v2,
              v3,
              {
                "kind": "LinkedField",
                "alias": null,
                "name": "supportedQtyTypes",
                "storageKey": null,
                "args": null,
                "concreteType": "QtyTypes",
                "plural": false,
                "selections": [
                  v4,
                  v5,
                  v2
                ]
              },
              v11,
              v12
            ]
          },
          v2
        ]
      }
    ]
  }
};
})();
// prettier-ignore
(node/*: any*/).hash = '9c38c2592f0c0a77cf2486d877b0ea7b';
module.exports = node;
