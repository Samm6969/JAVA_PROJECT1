import React, { Component } from 'react'

const AgentFundTradingRoute = ({ title }) =>
  class extends Component {
    render() {
      return <div>{title}</div>
    }
  }

export default AgentFundTradingRoute
