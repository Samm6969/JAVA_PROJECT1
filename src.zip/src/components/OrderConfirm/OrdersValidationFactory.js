import _ from 'lodash'

class OrdersValidationFactory {
  constructor(dataSet) {
    this.validationSrc = dataSet
  }

  getAllValidationsForGridView = () => {
    let response = []
    response = _.concat(
      response,
      this.applyValidationsForGridByErrorType('tradeInputValidationErrors'),
    )
    response = _.concat(
      response,
      this.applyValidationsForGridByErrorType(
        'tradeBusinessRulesValidationErrors',
      ),
    )
    response = _.concat(
      response,
      this.applyValidationsForGridByErrorType(
        'tradeComplianceRulesValidationErrors',
      ),
    )
    return response
  }

  applyValidationsForGridByErrorType = errorType => {
    if (errorType === 'tradeInputValidationErrors') {
      return this.getTradeInputValidationErrors()
    }
    if (errorType === 'tradeBusinessRulesValidationErrors') {
      return this.getTradeBusinessRulesValidationErrors(
        this.validationSrc.tradeBusinessRulesValidationErrors,
      )
    }
    return this.getTradeComplianceRulesValidationErrors()
  }

  getTradeInputValidationErrors = () => []

  getTradeBusinessRulesValidationErrors = errorDetails => {
    const response = []
    const iconClassesMap = {
      WARNING: 'glyphicon glyphicon-material-warning',
      ERROR: 'glyphicon glyphicon-material-error',
      RESTRICTED: 'glyphicon glyphicon-material-restricted',
    }
    _.forEach(errorDetails, entity => {
      response.push({
        iconClass: iconClassesMap[entity.errorLevel],
        message: entity.errorMessage,
      })
    })
    return response
  }

  getTradeComplianceRulesValidationErrors = () => []
}

export default OrdersValidationFactory
