import React from 'react'
import PropTypes from 'prop-types'
import _ from 'lodash'
import { Card, CardContent, Icon } from '@fc/react-playbook'
import cx from 'classnames'
import Order from './Order'
import s from './OrderList.scss'

const generateOrderEntityIndex = index => index
const warningMessagesLookup = [
  'Hard Cutoff', // 0
  'Market Value', // 1
  'Percentage Owned', // 2
  'Audit calculations could not be performed due to stale or insufficient data.', // 3
  'Before investing in mutual funds, it is important that you understand the sales charges, expenses and management fees that you may be charged. The prospectus link is displayed on the fund details page for the funds you are purchasing. Please click confirm to acknowledge that you have read and agreed to the terms as described', // 4
  'Audit calculations will not be performed on future dated trades.', // 5
  'Trade Window', // 6
  'Trade Date', // 7
  'Override Cutoff', // 8
  'Future Trade', // 9
  'Cash Payment Cutoff', // 10
  'Trade Lead Days', // 11
  'Before investing in mutual funds, it is important that you understand the sales charges, expenses and management fees that you may be charged. The prospectus and KIID links are displayed on the fund details page for the funds you are purchasing. Please click confirm to acknowledge that you have read and agreed to the terms as described', // 12
  'Redemption Gate', // 13
  'Redemption Liquidity Fee', // 14
  'Redemption Liquidity Fee (Estimated Fee Pct.)', // 15
  'Fund Daily Liquidity', // 16
  'Fund Weekly Liquidity', // 17
  'Fund Liquidity', // 18
  'Approval Trade Size', // 19
  'Daily Subscription', // 20
]

const OrderList = props => {
  const selectedFunds = []
  return (
    <div>
      {props.tradeValidationSummaryMessages.length ? (
        <Card>
          <CardContent>
            <ul>
              <div
                style={{
                  color: 'red',
                  fontWeight: 'bold',
                  paddingBottom: '0px',
                  paddingTop: '0px',
                }}
              >
                Note: One or more of the orders contains validation error(s) or
                warning(s).
              </div>
              {props.tradeValidationSummaryMessages.map(item => (
                <div>
                  {item === warningMessagesLookup[0] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Cutoff
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Hard Cutoff - the order was placed after the cutoff
                            time.
                          </span>
                        </li>
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Soft Cutoff - the order was placed after the cutoff
                            time but can still be submitted for processing. The
                            Fund Processor may still reject the order.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[10] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Cash Payment Cutoff
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Cash Payment Cutoff - the payment request was placed
                            after the custodian cash cutoff time.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[3] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Incomplete Audit
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Audit calculations could not be performed due to
                            stale or insufficient data.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[19] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Approval Trade Size
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Approval Required - Trade size surpasses the
                            subscription/redemption limit set by the
                            institution.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[1] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Market Value Limit
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Market Value Limit - This order amount surpasses the
                            institution\s or applicable account(s) market value
                            limit set at the fund level. If you choose to
                            process this order Fund Connect will automatically
                            reject the order.
                          </span>
                        </li>
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Market Value Limit - This order amount surpasses the
                            institution\s or applicable account(s) market value
                            limit set at the fund level but can still be
                            submitted for processing.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[2] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Percentage Owned Limit
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            % Owned Limit - This order amount surpasses the
                            institution\s or applicable account(s) % owned limit
                            set at the fund level. If you choose to process this
                            order Fund Connect will automatically reject the
                            order.
                          </span>
                        </li>
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            % Owned Limit - This order amount surpasses the
                            institution\s or applicable account(s) % owned limit
                            set at the fund level but can still be submitted for
                            processing.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[20] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Daily Subscription Limit
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Daily Subscription Limit - This order amount
                            surpasses your institution\s or applicable
                            account(s) daily subscription limit set at the fund
                            level. If you choose to continue this order will
                            automatically be rejected.
                          </span>
                        </li>
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Daily Subscription Limit - This order amount
                            surpasses your institution\s or applicable
                            account(s) daily subscription limit set at the fund
                            level but can still be submitted for processing.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[4] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Prospectus Review
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Before investing in mutual funds it is important
                            that you understand the sales charges expenses and
                            management fees that you may be charged. The
                            prospectus link is displayed on the fund details
                            page for the funds you are purchasing. Please click
                            confirm to acknowledge that you have read and agreed
                            to the terms as described.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[5] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Future Dated Trade
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Audit calculations will not be performed on future
                            dated trades.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}

                  {item === warningMessagesLookup[6] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Trade Window
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Trade Window - The fund is closed for trading. If
                            you choose to continue this order will automatically
                            be rejected.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[7] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Trade Date
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Trade Window - The trade date can only be the next
                            business day for this fund. If you choose to
                            continue this order will automatically be rejected.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[8] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Override Cutoff
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Trade Cutoff and Trade Window validation have been
                            bypassed.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[9] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Future Dated Trade
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Trade Window - Future dated trade is not supported
                            for this fund. If you choose to continue this order
                            will automatically be rejected.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[11] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Trade Date
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Trade Lead Days - Order must be submitted prior to
                            trade date. If you choose to continue this order
                            will automatically be rejected.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[12] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Prospectus Review
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Before investing in mutual funds it is important
                            that you understand the sales charges expenses and
                            management fees that you may be charged. The
                            prospectus and KIID links are displayed on the fund
                            details page for the funds you are purchasing.
                            Please click confirm to acknowledge that you have
                            read and agreed to the terms as described.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[13] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Redemption Gate
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-restricted"
                            className={cx(s.restricted)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Redemption gate is in effect. It will not be
                            possible to redeem shares until the gate has been
                            lifted.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[14] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Redemption Liquidity Fee
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Redemption liquidity fee is currently in effect for
                            this fund.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[15] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Estimated Fee Percentage
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Redemption liquidity fee is currently in effect for
                            this fund.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[16] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Fund Daily Liquidity Limit
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Fund Daily Liquidity Limit - Fund daily liquidity %
                            value is below institution\s or applicable
                            account(s) hard limit. If you choose to process this
                            order Fund Connect will automatically reject the
                            order.
                          </span>
                        </li>
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Fund Daily Liquidity Limit - Fund daily liquidity %
                            value is below institution\s or applicable
                            account(s) soft limit. This order can be submitted
                            for processing.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[17] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Fund Weekly Liquidity Limit
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon name="material-error" className={cx(s.error)} />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Fund Weekly Liquidity Limit - Fund weekly liquidity
                            % value is below institution\s or applicable
                            account(s) hard limit. If you choose to process this
                            order Fund Connect will automatically reject the
                            order.
                          </span>
                        </li>
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Fund Weekly Liquidity Limit - Fund weekly liquidity
                            % value is below institution\s or applicable
                            account(s) soft limit. This order can be submitted
                            for processing.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                  {item === warningMessagesLookup[18] && (
                    <div>
                      <p
                        style={{
                          lineHeight: '5pt',
                          fontWeight: 'bold',
                          fontFamily: 'Verdana, Helvetica, sans-serif',
                          fontSize: '11px',
                        }}
                      >
                        Fund Liquidity
                      </p>
                      <ul
                        style={{
                          listStyleType: 'none',
                          padding: '0px',
                        }}
                      >
                        <li>
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                          <Icon
                            name="material-warning"
                            className={cx(s.warning)}
                          />
                          <span
                            style={{
                              lineHeight: '11pt',
                              fontFamily: 'Verdana, Helvetica, sans-serif',
                              fontSize: '11px',
                            }}
                          >
                            Fund does not report daily/weekly liquidity
                            statistics.
                          </span>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : (
        ''
      )}
      <div>
        {props.orders.map((order, index) => {
          let fundName = null
          const selectedAccountEntitySet = order.fundAccount
          if (
            selectedFunds.indexOf(
              _.get(selectedAccountEntitySet, 'fund.name'),
            ) === -1
          ) {
            fundName = `${_.get(selectedAccountEntitySet, 'fund.name')}(${_.get(
              selectedAccountEntitySet,
              'fund.provider.name',
            )})`
            selectedFunds.push(_.get(selectedAccountEntitySet, 'fund.name'))
          }
          return (
            <Order
              key={generateOrderEntityIndex(index)}
              orderRequest={order}
              fundName={fundName}
            />
          )
        })}
      </div>
    </div>
  )
}

OrderList.propTypes = {
  orders: PropTypes.instanceOf(Array),
  tradeValidationSummaryMessages: PropTypes.instanceOf(Array),
}

export default OrderList
