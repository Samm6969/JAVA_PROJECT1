import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import moment from 'moment'
import { Icon } from '@fc/react-playbook'
import cx from 'classnames'
import OrdersValidationFactory from './OrdersValidationFactory'
import TimeFormatter from '../TimeFormatter/TimeFormatter'
import s from './Order.scss'

const setRowDivTagByGeneralEntity = (entity, index) => {
  if (!entity.val && entity.skipUndefined) {
    return <span key={index} />
  }
  return (
    <div className={cx(s.field)} key={index}>
      <div className={cx(entity.labelClass)}>{entity.label}</div>
      <div className={cx(entity.valClass)}>{entity.val}</div>
    </div>
  )
}

const fetchOrderRequestFormFields = entity => {
  // console.log('fetchOrderRequestFormFields ~~~~~~~~ ', entity)
  const formFields = []
  formFields.push({
    label: 'Order Side:',
    labelClass: [s.fieldLabel],
    val: entity.orderRequest.side,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Redemption Type:',
    labelClass: [s.fieldLabel],
    val: entity.orderRequest.redemptionFeeType,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Quantity Type:',
    labelClass: [s.fieldLabel],
    val: entity.orderRequest.qtyType,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Amount:',
    labelClass: [s.fieldLabel],
    val: entity.orderRequest.quantity,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Settlement Date:',
    labelClass: [s.fieldLabel],
    val: _.get(entity, 'orderRequest.settlementDate.name'),
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Trade Date:',
    labelClass: [s.fieldLabel],
    val: entity.orderRequest.tradeDate,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  return formFields
}

const getValidationDetails = values => {
  const validations = new OrdersValidationFactory(values)
  const validationDetails = validations.getAllValidationsForGridView()
  const getRowIndex = idx => idx
  return (
    <div className={s.flexColumn}>
      {validationDetails.map((error, index) => (
        <div className={s.flexRow} key={getRowIndex(index)}>
          <Icon name={error.iconClass} className={cx(s.warning)} />
          {error.message}{' '}
        </div>
      ))}
    </div>
  )
}

const formatSelectedTradeWindowDisplayText = (entity, timeZone) => {
  if (entity.orderRequest.userTradeWindowId > 0) {
    const tradeWindow = _.find(
      entity.fundAccount.tradeWindows,
      item => item.tradeWindowsId === entity.orderRequest.userTradeWindowId,
    )
    const {
      redEndTime,
      subEndTime,
      redemptionSettlementPeriod,
      subscriptionSettlementPeriod,
    } = tradeWindow

    const tz = moment.tz(timeZone).zoneAbbr()
    return (
      <div className={s.field}>
        <div className={s.fieldLabel}>Trade Window:</div>
        <div
          className={s.rightAlign}
          style={{ display: 'flex', flexDirection: 'column' }}
        >
          {entity.orderRequest.userTradeWindowId === 0 ? (
            <div>Not Avaiable</div>
          ) : (
            <div>
              <div className={s.field}>
                <span style={{ paddingRight: '5px' }}>Time</span>
                <span style={{ paddingRight: '5px' }}>
                  ({tz}
                  ):
                </span>
                <span>Buy:</span>
                <TimeFormatter time={subEndTime} showTimeZone={false} />
                <span style={{ paddingLeft: '5px', paddingRight: '5px' }}>
                  {' '}
                  |{' '}
                </span>
                <span>Sell:</span>
                <TimeFormatter time={redEndTime} showTimeZone={false} />
              </div>
              <div className={s.field}>
                <span style={{ paddingRight: '5px' }}>Settlement Period: </span>
                <span style={{ paddingRight: '5px' }}>
                  (T+
                  {subscriptionSettlementPeriod})
                </span>
                <span style={{ paddingLeft: '4px', paddingRight: '5px' }}>
                  {' '}
                  |{' '}
                </span>
                <span>
                  (T+
                  {redemptionSettlementPeriod})
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }
  return <div />
}

const showStandingInstructionLabel = (item, orderRequest) => {
  if (
    item.defaultCurrencySSI &&
    orderRequest.fundAccount.account.autoPopulateDefaultSsi
  )
    return <span>(Standing Instruction)</span>
  return <span />
}

const fetchSettlementInstructions = (label, path, val, list, orderRequest) => {
  const localvalue = `${val} `
  const listItem = _.find(list, o => _.get(o, path) === localvalue.trim())
  return listItem ? (
    <div className={s.flexColumn}>
      <div className={s.field}>
        <div className={s.fieldLabel}>{label}</div>
        <div className={s.fieldLabel}>
          {listItem.displayName}
          {showStandingInstructionLabel(listItem, orderRequest)}
        </div>
      </div>
      <div className={cx(s.flexRow, s.flexRowContentCenter)}>
        {localvalue.trim() === '-99' ? (
          <div />
        ) : (
          <div className={s.flexColumn}>
            {setRowDivTagByGeneralEntity(
              {
                label: 'SSI Custodian Name:',
                labelClass: [s.instructionLabel, s.fontSize12],
                val: listItem.custodianName,
                valClass: [s.fontSize12],
                skipUndefined: true,
              },
              'custodianName',
            )}
            {setRowDivTagByGeneralEntity(
              {
                label: 'SSI Custodian Account:',
                labelClass: [s.instructionLabel, s.fontSize12],
                val: listItem.custodianAccount,
                valClass: [s.fontSize12],
                skipUndefined: true,
              },
              'custodianAccount',
            )}
            {setRowDivTagByGeneralEntity(
              {
                label: 'SSI Custodian BIC:',
                labelClass: [s.instructionLabel, s.fontSize12],
                val: listItem.custodianBIC,
                valClass: [s.fontSize12],
                skipUndefined: true,
              },
              'custodianBIC',
            )}
            {setRowDivTagByGeneralEntity(
              {
                label: 'Cash Cutoff Time:',
                labelClass: [s.instructionLabel, s.fontSize12],
                val: listItem.cashCutoffTimeDisplay,
                valClass: [s.fontSize12],
                skipUndefined: true,
              },
              'cashCutoffTimeDisplay',
            )}
          </div>
        )}
      </div>
    </div>
  ) : (
    ''
  )
}

const fetchFundAccountFormFields = orderRequest => {
  // console.log('fetchFundAccountFormFields ~~~~~~~~ ', orderRequest)
  const formFields = []
  formFields.push({
    label: 'Account:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.account.name,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Market Value:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.balance.balanceAmt,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Total Share:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.balance.shares,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Est. Market Value:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.balance.balanceAmt,
    valClass: [s.rightAlign],
    skipUndefined: false,
  })
  formFields.push({
    label: 'Est. Share:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.estimatedShare,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Fund % Owned:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.fundPercentOwned,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Est. Total Market Value:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.estimatedTotalMarketValue,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Est. Total Share:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.estimatedTotalShare,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Comments:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.comments,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  formFields.push({
    label: 'Approval Messages:',
    labelClass: [s.fieldLabel],
    val: orderRequest.fundAccount.approvalMessage,
    valClass: [s.rightAlign],
    skipUndefined: true,
  })
  return formFields
}

const Orders = props => {
  const { orderRequest } = props
  const showValidations =
    orderRequest.tradeBusinessRulesValidationErrors.length ||
    orderRequest.tradeComplianceRulesValidationErrors.length
  return (
    <div className={s.column}>
      <div className={s.fund}>
        {props.fundName ? <div>{props.fundName}</div> : ''}
      </div>
      <div className={cx(s.row)}>
        {fetchFundAccountFormFields(orderRequest).map((item, index) =>
          setRowDivTagByGeneralEntity(item, index),
        )}
      </div>
      <div className={cx(s.row)}>
        {fetchOrderRequestFormFields(orderRequest).map((item, index) =>
          setRowDivTagByGeneralEntity(item, index),
        )}
        {showValidations ? (
          <div className={cx(s.field)}>
            <div className={cx(s.fieldLabel)}>Validations:</div>
            <div className={cx(s.rightAlign)}>
              {getValidationDetails(orderRequest)}
            </div>
          </div>
        ) : (
          ''
        )}
        {formatSelectedTradeWindowDisplayText(orderRequest)}
      </div>
      <div className={cx(s.flexRow, s.bgColor, s.flexRowContentSpaceAround)}>
        {fetchSettlementInstructions(
          'Cash Settlement Instructions:',
          'cashInstructionId',
          orderRequest.orderRequest.investorCashSettlementInstruction,
          orderRequest.fundAccount.cashInstructions,
          orderRequest,
        )}
        {fetchSettlementInstructions(
          'Custody Settlement Instructions:',
          'custodyInstructionId',
          orderRequest.orderRequest.investorCustodySettlementInstruction,
          orderRequest.fundAccount.custodyInstructions,
          orderRequest,
        )}
      </div>
    </div>
  )
}

Orders.propTypes = {
  orderRequest: PropTypes.instanceOf(Object),
  fundName: PropTypes.string,
}
export default Orders
