import React, { Component } from 'react'
import PropTypes from 'prop-types'
import ReactDatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import momentPropTypes from 'react-moment-proptypes'

import Input from '../Input'
import DatePickerPortal from './DatePickerPortal'

class DatePicker extends Component {
  static propTypes = {
    value: PropTypes.oneOfType([PropTypes.string, momentPropTypes.momentObj]),
  }

  render() {
    const { value, ...rest } = this.props
    return (
      <ReactDatePicker
        showMonthDropdown
        showYearDropdown
        scrollableYearDropdown
        todayButton="Today"
        customInput={<Input type="text" />}
        popperContainer={DatePickerPortal}
        {...rest}
      />
    )
  }
}

export default DatePicker
