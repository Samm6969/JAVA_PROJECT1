import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'

import s from './TextArea.scss'

class TextArea extends Component {
  static propTypes = {
    error: PropTypes.bool,
    className: PropTypes.string,
    maxlength: PropTypes.number,
  }

  static defaultProps = {
    className: '',
  }

  render() {
    const { className, maxlength } = this.props
    return (
      <textarea
        {...this.props}
        maxLength={maxlength}
        className={cx(className, s.input)}
      />
    )
  }
}

export default TextArea
