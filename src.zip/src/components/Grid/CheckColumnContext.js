import { createContext } from 'react'

export const {
  Provider: CheckColumnProvider,
  Consumer: CheckColumnConumer,
} = createContext({})
