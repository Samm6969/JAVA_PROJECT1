import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'
import _ from 'lodash'

import s from './GridHeader.scss'
import GridCell from './GridCell'
import CheckColumn from './CheckColumn'
import { CheckColumnConumer } from './CheckColumnContext'

class GridHeader extends PureComponent {
  static propTypes = {
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        text: PropTypes.string,
      }),
    ),
    rowHeight: PropTypes.number,
    // scrollLeft: PropTypes.number,
    rendered: PropTypes.func,
  }

  static getColumnId({ id, dataIndex, text }) {
    return _.kebabCase(`${id || dataIndex || text}-column`)
  }

  componentDidMount() {
    this.handleRendered()
  }

  componentDidUpdate() {
    this.handleRendered()
  }

  handleRendered = () => {
    const { rendered } = this.props
    if (typeof rendered === 'function') {
      rendered(this.renderedColumns)
    }
  }

  renderLockedColumns = () => {
    const { columns } = this.props
    return columns.map(column => this.columnRenderer(column, true))
  }

  renderColumns = () => {
    const { columns } = this.props
    return columns.map(column => this.columnRenderer(column))
  }

  columnRenderer = (
    { children: allChildren, ...column },
    lockedOnly = false,
  ) => {
    const {
      text,
      width,
      hidden = false,
      locked = false,
      hideable = true,
      flex = 1,
      minWidth = 50,
      maxWidth = 'none',
      isGroupHeader = false,
      isFirstColumnInGroup = false,
      xtype = 'column',
    } = column

    const id = GridHeader.getColumnId(column)
    const { rowHeight } = this.props
    if (hidden && hideable) {
      return null
    }

    if (Array.isArray(allChildren)) {
      const children = allChildren.filter(
        ({
          hidden: childHidden,
          hideable: childHideable = true,
          locked: childLocked = false,
        }) =>
          lockedOnly
            ? childLocked && (!childHidden || !childHideable)
            : !childLocked && (!childHidden || !childHideable),
      )

      if (children.length === 0) {
        return null
      }

      return (
        <div
          id={id}
          key={id}
          className={s.groupWrapper}
          style={{ flex: flex + children.length - 1 }}
        >
          {this.columnRenderer(
            { isGroupHeader: true, ...column, locked: lockedOnly },
            lockedOnly,
          )}
          <div className={s.group}>
            {children.map((childColumn, index) =>
              this.columnRenderer(
                {
                  ...childColumn,
                  flex: flex + children.length,
                  isFirstColumnInGroup: index === 0,
                },
                lockedOnly,
              ),
            )}
          </div>
        </div>
      )
    }

    if ((lockedOnly && !locked) || (!lockedOnly && locked)) {
      return null
    }

    const columnConfig = {
      ...column,
      id,
      text,
      width,
      hidden,
      locked,
      hideable,
      flex,
      minWidth,
      maxWidth,
      isGroupHeader,
      isFirstColumnInGroup,
      xtype,
    }
    if (!isGroupHeader) {
      this.renderedColumns.push(columnConfig)
    }

    return (
      <GridCell
        id={id}
        key={id}
        className={cx(s.cell, {
          [s.groupHeader]: isGroupHeader,
          [s.isFirstColumnInGroup]: isFirstColumnInGroup,
        })}
        innerCellProps={{
          className: s.innerCell,
        }}
        style={{
          width,
          flex,
          minWidth: isGroupHeader ? '100%' : width || minWidth,
          maxWidth: isGroupHeader ? '100%' : width || maxWidth,
          minHeight: rowHeight,
          lineHeight: `${rowHeight}px`,
        }}
      >
        {xtype === 'column' && text}
        {xtype === 'checkcolumn' && (
          <CheckColumnConumer>
            {props => <CheckColumn isHeader {...props} column={columnConfig} />}
          </CheckColumnConumer>
        )}
      </GridCell>
    )
  }

  renderedColumns = []

  render() {
    this.renderedColumns = []
    return (
      <div className={s.wrapper} id="grid-header">
        <div id="header-locked-column-container" className={s.lockedContainer}>
          {this.renderLockedColumns()}
        </div>
        <div className={s.columnContainer}>
          <div
            id="header-column-container"
            style={{
              display: 'flex',
              position: 'relative',
            }}
          >
            {this.renderColumns()}
          </div>
        </div>
      </div>
    )
  }
}

export default GridHeader
