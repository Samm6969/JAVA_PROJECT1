import PropTypes from 'prop-types'

export const sorterProps = PropTypes.shape({
  field: PropTypes.string.isRequired,
  dir: PropTypes.oneOf(['DESC', 'ASC']).isRequired,
})

export const headerProps = PropTypes.oneOfType([
  PropTypes.string,
  PropTypes.func,
])

export const columnProp = PropTypes.shape({
  header: headerProps.isRequired,
  dataIndex: PropTypes.string.isRequired,
  renderer: PropTypes.func,
  style: PropTypes.object,
  className: PropTypes.string,
})

const groupByConfig = PropTypes.shape({
  path: PropTypes.string,
  uniqueIdPath: PropTypes.string,
  header: PropTypes.string,
  renderPath: PropTypes.string,
})

export const groupByProps = PropTypes.shape({
  parent: groupByConfig,
  child: groupByConfig,
})

const columnGroupShape = { header: headerProps.isRequired }

columnGroupShape.columns = PropTypes.arrayOf(
  PropTypes.oneOfType([columnProp, PropTypes.shape(columnGroupShape)]),
)

export const columnsProp = PropTypes.arrayOf(
  PropTypes.oneOfType([columnProp, PropTypes.shape(columnGroupShape)]),
)

export const stateProps = PropTypes.shape({
  columns: columnsProp.isRequired,
  sorter: sorterProps,
  groupBy: groupByProps,
})

export const statePropsAllowShortcutColumns = PropTypes.shape({
  columns: PropTypes.oneOfType([
    columnsProp,
    PropTypes.arrayOf(PropTypes.string),
  ]).isRequired,
  sorter: sorterProps,
  groupBy: groupByProps,
})
