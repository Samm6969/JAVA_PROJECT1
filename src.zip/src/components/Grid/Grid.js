import React, { Fragment, PureComponent } from 'react'
import { LoadingIndicator } from '@fc/react-playbook'
import ReactResizeDetector from 'react-resize-detector'
import { AutoSizer } from 'react-virtualized'
import PropTypes from 'prop-types'
import { ScrollSync } from 'react-scroll-sync'
import _ from 'lodash'

import GridHeader from './GridHeader'

import s from './Grid.scss'
import GridWindow from './GridWindow'
import GridCell from './GridCell'
import { CheckColumnProvider, CheckColumnConumer } from './CheckColumnContext'
import { isUndefinedNull } from '../../utils/utils'
import CheckColumn from './CheckColumn'

class Grid extends PureComponent {
  static propTypes = {
    id: PropTypes.string.isRequired,
    width: PropTypes.number,
    height: PropTypes.number,
    rowHeight: PropTypes.number,
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string,
        dataIndex: PropTypes.string,
        // eslint-disable-next-line
        text(props, propName, componentName) {
          if (typeof props.xtype === 'string' && props.xtype !== 'column') {
            return PropTypes.checkPropTypes(
              { text: PropTypes.node },
              props,
              propName,
              componentName,
            )
          }
          return PropTypes.checkPropTypes(
            { text: PropTypes.node.isRequired },
            props,
            propName,
            componentName,
          )
        },
        renderer: PropTypes.func,
      }),
    ).isRequired,
    // eslint-disable-next-line react/forbid-prop-types
    data: PropTypes.array,
    isLoading: PropTypes.bool,
    emptyCellText: PropTypes.node,
    onSelectionChanged: PropTypes.func,
    onSelect: PropTypes.func,
    onDeselect: PropTypes.func,
  }

  static defaultProps = {
    width: null,
    height: null,
    rowHeight: 40,
    emptyCellText: '--',
  }

  recordIdProp = Symbol('recordId')

  constructor(props) {
    super(props)
    this.node = React.createRef()
  }

  state = {
    renderedColumns: [],
    scrollLeft: 0,
    selected: {},
    data: [],
  }

  onResizeGrid = (fillWidth, fillHeight) => {
    const { width, height } = this.props
    const nextWidth = `${fillWidth}px`
    const nextHeight = `${fillHeight}px`

    if (!width) {
      this.node.current.style.width = nextWidth
      this.node.current.style.maxWidth = nextWidth
    }

    if (!height) {
      this.node.current.style.height = nextHeight
      this.node.current.style.maxHeight = nextHeight
    }
  }

  onHeaderRender = nextRenderedColumns => {
    const { renderedColumns } = this.state
    if (renderedColumns.length === 0) {
      this.setState({
        renderedColumns: nextRenderedColumns,
      })
    }
  }

  onSelectionChanged = ({ column, record }) => {
    const { onSelectionChanged } = this.props
    if (typeof onSelectionChanged === 'function') {
      const { selected } = this.state
      onSelectionChanged(selected, column, record)
    }
  }

  onSelect = ({ column, record }) => {
    const { onSelect } = this.props

    if (typeof onSelect === 'function') {
      onSelect(record, column)
    }

    const { id } = column
    this.setState(
      ({ selected }) => {
        let currentSelection = selected[id] || []
        if (!record) {
          const { data } = this.state
          currentSelection = [...data]
        } else {
          currentSelection.push(record)
        }
        return {
          selected: {
            ...selected,
            [id]: currentSelection,
          },
        }
      },
      () => {
        this.onSelectionChanged({ column, record })
      },
    )
  }

  onDeselect = ({ column, record }) => {
    const { onDeselect } = this.props
    if (typeof onDeselect === 'function') {
      onDeselect(column, record)
    }

    const { id } = column
    this.setState(
      ({ selected }) => {
        let currentSelection = selected[id] || []
        if (record) {
          // eslint-disable-next-line no-underscore-dangle
          _.remove(currentSelection, selection => selection._id === record._id)
        } else {
          currentSelection = []
        }
        return {
          selected: {
            ...selected,
            [id]: currentSelection,
          },
        }
      },
      () => {
        this.onSelectionChanged({ column, record })
      },
    )
  }

  getColumnWidth = ({ columnIndex }) => {
    if (typeof document === 'undefined') {
      return 'auto'
    }

    const { renderedColumns } = this.state
    const column = renderedColumns[columnIndex]
    const node = document.getElementById(column.id)

    return node.offsetWidth
  }

  loadData = (data = []) => {
    this.setState({
      data: data.map((record, index) => ({
        ...record,
        _id: `record-${index}`,
      })),
    })
  }

  defaultRenderer = value => {
    const { emptyCellText } = this.props
    if (typeof value === 'object' || isUndefinedNull(value)) {
      return emptyCellText
    }
    return value
  }

  cellRenderer = ({ columnIndex, rowIndex, style }) => {
    const { renderedColumns, data } = this.state
    if (data.length === 0) {
      return null
    }
    const column = renderedColumns[columnIndex]
    const { dataIndex, renderer: ColumnRenderer, xtype } = column
    const record = data[rowIndex]
    const value = _.get(record, dataIndex)

    return (
      <GridCell key={columnIndex} style={style}>
        {xtype === 'column' &&
          typeof ColumnRenderer === 'function' && (
            <ColumnRenderer
              value={value}
              record={record}
              dataIndex={dataIndex}
              column={column}
              columnIndex={columnIndex}
            />
          )}
        {xtype === 'column' &&
          typeof ColumnRenderer !== 'function' &&
          this.defaultRenderer(value)}
        {xtype === 'checkcolumn' && (
          <CheckColumnConumer>
            {props => (
              <CheckColumn
                value={value}
                record={record}
                dataIndex={dataIndex}
                column={column}
                columnIndex={columnIndex}
                {...props}
              />
            )}
          </CheckColumnConumer>
        )}
      </GridCell>
    )
  }

  render() {
    const { id, width, height, columns, rowHeight, isLoading } = this.props
    const { renderedColumns, scrollLeft, selected, data } = this.state
    const hasData = data.length !== 0
    const headerRendered = renderedColumns.length !== 0
    const lockedColumns = renderedColumns.filter(({ locked }) => locked)
    const style = {
      width,
      height,
    }
    return (
      <Fragment>
        <ReactResizeDetector
          handleWidth={!width}
          handleHeight={!height}
          onResize={this.onResizeGrid}
        />
        <ScrollSync>
          <CheckColumnProvider
            value={{
              onSelectionChanged: this.onSelectionChanged,
              onSelect: this.onSelect,
              onDeselect: this.onDeselect,
              selected,
              totalCount: data.length,
            }}
          >
            <div id={id} ref={this.node} style={style} className={s.grid}>
              <GridHeader
                columns={columns}
                rowHeight={rowHeight}
                rendered={this.onHeaderRender}
                scrollLeft={scrollLeft}
              />
              <div className={s.body}>
                {headerRendered &&
                  hasData && (
                    <AutoSizer>
                      {({ height: autoHeight, width: autoWidth }) => (
                        <GridWindow
                          width={autoWidth}
                          height={autoHeight}
                          cellRenderer={this.cellRenderer}
                          columnWidth={this.getColumnWidth}
                          columnCount={renderedColumns.length}
                          lockedColumnCount={lockedColumns.length}
                          rowHeight={rowHeight}
                          rowCount={data.length}
                        />
                      )}
                    </AutoSizer>
                  )}
                {isLoading && <LoadingIndicator />}
              </div>
            </div>
          </CheckColumnProvider>
        </ScrollSync>
      </Fragment>
    )
  }
}

export default Grid
