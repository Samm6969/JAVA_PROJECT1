import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'

import s from './Input.scss'

class Input extends Component {
  static propTypes = {
    error: PropTypes.bool,
    className: PropTypes.string,
    type: PropTypes.string,
  }

  static defaultProps = {
    className: '',
  }

  render() {
    const { className, type } = this.props

    const conditionalClassNames = {
      [s.text]: type === 'text',
    }

    return (
      <input
        {...this.props}
        className={cx(className, s.input, conditionalClassNames)}
        type={type}
      />
    )
  }
}

export default Input
