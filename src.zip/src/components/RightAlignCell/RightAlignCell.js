import React, { Component } from 'react'
import cx from 'classnames'
import PropTypes from 'prop-types'

import s from './RightAlignCell.scss'

class RightAlignCell extends Component {
  static propTypes = {
    className: PropTypes.string,
    children: PropTypes.node,
  }

  static defaultProps = {
    className: '',
  }

  render() {
    const { className, children } = this.props
    if (typeof children === 'undefined') {
      return null
    }
    return <div className={cx(s.rightAlign, className)}>{children}</div>
  }
}

export default RightAlignCell
