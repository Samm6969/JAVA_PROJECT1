import React, { PureComponent } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'
import _ from 'lodash'
import getDisplayName from '@fc/react-playbook/src/utils/getDisplayName'

import s from './FormGroup.scss'
import { ReduxFormConsumer } from '../../hoc/reduxForm'

const formGroup = WrappedComponent => {
  class FormGroupComponent extends PureComponent {
    static displayName = getDisplayName('formGroup', WrappedComponent)

    static propTypes = {
      // eslint-disable-next-line react/forbid-foreign-prop-types
      ...WrappedComponent.propTypes,
      label: PropTypes.node,
      // eslint-disable-next-line react/forbid-prop-types
      input: PropTypes.object,
      // eslint-disable-next-line react/forbid-prop-types
      meta: PropTypes.object,
      inline: PropTypes.bool,
      className: PropTypes.string,
      formGroupClassName: PropTypes.string,
      formGroupLabelClassName: PropTypes.string,
      delimiter: PropTypes.string,
      showDelimiter: PropTypes.bool,
      showUntouchedErrors: PropTypes.bool,
      showUntouchedWarnings: PropTypes.bool,
      setInitialValue: PropTypes.func,
      align: PropTypes.oneOf(['left', 'center', 'right']),
    }

    static defaultProps = {
      className: '',
      delimiter: ':',
      input: {},
      meta: {},
    }

    componentDidMount() {
      const { input, setInitialValue, defaultValue } = this.props
      const { name } = input

      if (!_.isEmpty(defaultValue) && typeof setInitialValue === 'function') {
        setInitialValue(name, defaultValue)
      }
    }

    get id() {
      const { input, meta } = this.props
      const { name } = input
      const { form } = meta

      return _.kebabCase(`${form}-${name}`)
    }

    render() {
      const {
        label,
        input,
        meta,
        inline,
        className,
        formGroupClassName,
        formGroupLabelClassName,
        showDelimiter,
        delimiter,
        setInitialValue,
        align,
        showUntouchedErrors,
        showUntouchedWarnings,
        ...props
      } = this.props
      const { id } = this

      const textAlignClassNames = cx({
        [s.leftAlign]: align === 'left',
        [s.rightAlign]: align === 'right',
        [s.centerAlign]: align === 'center',
      })

      return (
        <div
          className={cx(formGroupClassName, s.wrapper, {
            [s.inline]: inline,
          })}
        >
          {label && (
            <label
              htmlFor={id}
              className={cx(
                formGroupLabelClassName,
                s.label,
                textAlignClassNames,
              )}
            >
              {label}
              {showDelimiter && delimiter}
            </label>
          )}
          <WrappedComponent
            id={id}
            {...props}
            {...input}
            meta={meta}
            className={cx(className, s.field, textAlignClassNames)}
          />
          <div className={cx(s.errorMessages, textAlignClassNames)}>
            {((meta.touched && !meta.active && meta.error) ||
              showUntouchedErrors) && (
              <span className={s.error}>{meta.error}</span>
            )}
          </div>
          <div className={cx(s.errorMessages, textAlignClassNames)}>
            {((meta.touched && !meta.active && meta.warning) ||
              showUntouchedWarnings) && (
              <span className={s.warning}>{meta.warning}</span>
            )}
          </div>
        </div>
      )
    }
  }
  return props => (
    <ReduxFormConsumer>
      {({ setInitialValue }) => (
        <FormGroupComponent {...props} setInitialValue={setInitialValue} />
      )}
    </ReduxFormConsumer>
  )
}

export default formGroup
