import { GraphQLObjectType, GraphQLString, GraphQLEnumType } from 'graphql'
import { globalIdField } from 'graphql-relay'
import _ from 'lodash'

import { nodeInterface } from './node'

// eslint-disable-next-line import/prefer-default-export
export const createType = ({ name, fields, idFetcher }) => {
  const globalIdFieldArgs = [name]
  if (idFetcher) {
    globalIdFieldArgs.push(idFetcher)
  }

  return new GraphQLObjectType({
    name,
    interfaces: () => [nodeInterface],
    fields: {
      id: globalIdField(...globalIdFieldArgs),
      [_.camelCase(`${name}Id`)]: {
        type: GraphQLString,
        resolve(...args) {
          const [parent] = args
          return idFetcher ? idFetcher(...args) : parent.id
        },
      },
      ...fields,
    },
  })
}

export const createEnum = (name, values) =>
  new GraphQLEnumType({ name, values })
