import {
  GraphQLBoolean,
  GraphQLFloat,
  GraphQLInt,
  GraphQLString,
} from 'graphql'
import { createType } from '../schemaHelpers'
import FundAccountType from './FundAccountType'
import OrderQtyTypeEnum from '../enums/OrderQtyTypeEnum'
import CurrencyType from './CurrencyType'
import OrderStatusEnum from '../enums/OrderStatusEnum'
import AssetTypeEnum from '../enums/AssetTypeEnum'
import ReferenceIdTypeEnum from '../enums/ReferenceIdTypeEnum'
import OrderSideEnum from '../enums/OrderSideEnum'

const OrderType = {
  name: 'Order',
  idFetcher: ({ orderId }) => orderId,
  fields: {
    orderId: { type: GraphQLInt },
    fundAccount: {
      type: FundAccountType,
      async resolve(parent, args, context) {
        return context.getFundAccountByIds.load(parent.fundAccountDTO.id)
      },
    },
    side: { type: OrderSideEnum },
    currency: { type: CurrencyType },
    orderStatus: { type: OrderStatusEnum },
    quantity: { type: GraphQLFloat },
    qtyType: { type: OrderQtyTypeEnum },
    qtyDecimals: { type: GraphQLInt },
    sharePrecision: { type: GraphQLInt },
    investorUid: { type: GraphQLString },
    submitDate: { type: GraphQLString },
    tradeDate: { type: GraphQLString },
    updateDate: { type: GraphQLString },
    settlementDate: { type: GraphQLString },
    etfSecuritiesDealDate: { type: GraphQLString },
    etfOrderType: { type: GraphQLString },
    assistedTrade: { type: GraphQLBoolean },
    numberOfApprovalsRequired: { type: GraphQLInt },
    numberOfApprovalsObtained: { type: GraphQLInt },
    numberOfCashApprovalsRequired: { type: GraphQLInt },
    numberOfCashApprovalsObtained: { type: GraphQLInt },
    numberOfCustodyApprovalsRequired: { type: GraphQLInt },
    numberOfCustodyApprovalsObtained: { type: GraphQLInt },
    cashSettlementStatus: { type: GraphQLString },
    custodySettlementStatus: { type: GraphQLString },
    underlyingAssetType: { type: AssetTypeEnum },
    referenceId: { type: GraphQLInt },
    referenceIdType: { type: ReferenceIdTypeEnum },
  },
}
export default createType(OrderType)
