import { createEnum } from '../schemaHelpers'

export default createEnum('RedemptionFeeTypeEnum', {
  NET: {},
  GROSS: {},
})
