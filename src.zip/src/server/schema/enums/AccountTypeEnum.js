import { createEnum } from '../schemaHelpers'

export default createEnum('AccountTypeEnum', {
  FULLY_DISCLOSED: {},
  OMNI: {},
})
