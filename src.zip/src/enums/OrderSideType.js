export default {
  BUY: 'BUY',
  SELL: 'SELL',
  CREATE: 'CREATE',
  REDEEM: 'REDEEM',
}
