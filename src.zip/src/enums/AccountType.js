export default {
  FULLY_DISCLOSED: 'FULLY_DISCLOSED',
  OMNI: 'OMNI',
}
