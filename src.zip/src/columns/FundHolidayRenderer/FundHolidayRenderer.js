import React, { Component } from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'

import s from './FundHolidayRenderer.scss'
import RightAlignCell from '../../components/RightAlignCell'

class FundHolidayRenderer extends Component {
  static propTypes = {
    className: PropTypes.string,
    rightAlign: PropTypes.bool,
  }

  render() {
    const { rightAlign, className, ...rest } = this.props

    const children = (
      <span className={cx(s.closed, className)} {...rest}>
        Closed
      </span>
    )

    if (rightAlign) {
      return <RightAlignCell>{children}</RightAlignCell>
    }

    return children
  }
}

export default FundHolidayRenderer
