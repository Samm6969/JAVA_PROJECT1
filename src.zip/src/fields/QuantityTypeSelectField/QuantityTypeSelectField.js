import React, { Component } from 'react'
import PropTypes from 'prop-types'
import _ from 'lodash'
import { Field, untouch as untouchAction, change } from 'redux-form'
import { connect } from 'react-redux'

import withReduxFormContext from '../../hoc/withReduxFormContext'
import { isUndefinedNull } from '../../utils/utils'

import { SelectField } from '../fields'

const requiredField = value => {
  if (typeof value !== 'object' || isUndefinedNull(value)) {
    return 'This field is required'
  }
  return undefined
}

const mapDispatchToProps = (dispatch, { section, name }) => ({
  untouch: () =>
    dispatch(untouchAction(section.form, `${section.sectionPrefix}.${name}`)),
  setFormValue: value =>
    dispatch(change(section.form, `${section.sectionPrefix}.${name}`, value)),
})

@withReduxFormContext
@connect(
  null,
  mapDispatchToProps,
)
class QuantityTypeSelectField extends Component {
  static propTypes = {
    // eslint-disable-next-line react/forbid-prop-types
    props: PropTypes.object,
    supportQtyTypes: PropTypes.shape({
      buy: PropTypes.arrayOf(PropTypes.string),
      sell: PropTypes.arrayOf(PropTypes.string),
    }).isRequired,
    orderSide: PropTypes.string,
    required: PropTypes.bool,
    untouch: PropTypes.func.isRequired,
    setFormValue: PropTypes.func.isRequired,
  }

  state = {
    orderSide: undefined,
    options: [],
  }

  static getDerivedStateFromProps(props, state) {
    const { orderSide, untouch, setFormValue, supportQtyTypes } = props
    const { orderSide: prevOrderSide } = state

    if (orderSide !== prevOrderSide) {
      const supportQtyTypesBySide = supportQtyTypes[_.toLower(orderSide)] || []

      const options = supportQtyTypesBySide.map(option => ({
        value: option,
        label: option,
      }))

      untouch()
      if (options.length === 1) {
        setFormValue(options[0])
      } else {
        setFormValue(null)
      }
      return {
        orderSide,
        options,
      }
    }

    return {
      orderSide,
    }
  }

  render() {
    const { props, required, ...rest } = this.props
    const { orderSide, options } = this.state

    const isDisabled = !orderSide || options.length === 1

    const validate = []

    if (required && !isDisabled) {
      validate.push(requiredField)
    }

    const styles = {
      container: base => ({
        ...base,
        width: 150,
      }),
    }

    return (
      <Field
        {...rest}
        // validate={this.validate}
        props={{
          options,
          isDisabled,
          label: 'Quantity Type',
          styles,
          ...props,
        }}
        component={SelectField}
        validate={validate}
      />
    )
  }
}

export default QuantityTypeSelectField
