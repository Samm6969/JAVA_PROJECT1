import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Field } from 'redux-form'
import moment from 'moment'

import { DatePickerInput } from '../fields'

class TradeDateField extends Component {
  static propTypes = {
    // eslint-disable-next-line react/forbid-prop-types
    props: PropTypes.object,
  }

  state = {
    selected: moment(),
  }

  onChange = (e, date) => {
    this.setState({ selected: date })
  }

  filterDate = date => moment(date).isSameOrAfter(Date.now(), 'day')

  render() {
    const { props, ...rest } = this.props
    const { selected } = this.state

    return (
      <Field
        {...rest}
        props={{
          selected,
          filterDate: this.filterDate,
          label: 'Trade Date',
          defaultValue: selected,
          ...props,
        }}
        onChange={this.onChange}
        component={DatePickerInput}
      />
    )
  }
}

export default TradeDateField
