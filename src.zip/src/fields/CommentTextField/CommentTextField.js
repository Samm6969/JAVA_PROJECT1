import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Field } from 'redux-form'

import { CommentField } from '../fields'

class CommentTextField extends Component {
  static propTypes = {
    // eslint-disable-next-line react/forbid-prop-types
    props: PropTypes.object,
    name: PropTypes.string,
  }

  render() {
    const { props, ...rest } = this.props
    return (
      <Field
        {...rest}
        props={{ label: 'Comment', ...props }}
        component={CommentField}
      />
    )
  }
}

export default CommentTextField
