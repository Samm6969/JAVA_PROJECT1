// eslint-disable-next-line
export const dummyData = [
  {
    id: 1,
    name: 'Buy',
  },
  {
    id: 2,
    name: 'Sell',
  },
]
