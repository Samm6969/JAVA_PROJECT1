import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Field } from 'redux-form'
import { isUndefinedNull } from '../../utils/utils'

import { SelectField } from '../fields'

const requiredField = value => {
  if (typeof value !== 'object' || isUndefinedNull(value)) {
    return 'This field is required'
  }
  return undefined
}

class OverrideSettlementDateField extends Component {
  static options = [
    {
      value: 1,
      label: 'Same Day',
    },
    {
      value: 2,
      label: 'Next Day',
    },
  ]

  static propTypes = {
    // eslint-disable-next-line react/forbid-prop-types
    props: PropTypes.object,
    required: PropTypes.bool,
  }

  render() {
    const { props, required, ...rest } = this.props
    const validate = []

    if (required) {
      validate.push(requiredField)
    }

    const styles = {
      container: base => ({
        ...base,
        width: 130,
      }),
    }

    return (
      <Field
        {...rest}
        props={{
          options: OverrideSettlementDateField.options,
          label: 'Settlement Date',
          styles,
          ...props,
        }}
        validate={validate}
        component={SelectField}
      />
    )
  }
}

export default OverrideSettlementDateField
