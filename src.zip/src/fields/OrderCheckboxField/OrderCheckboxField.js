import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Field } from 'redux-form'

import { CheckboxField } from '../fields'

class OrderCheckboxField extends Component {
  static propTypes = {
    // eslint-disable-next-line react/forbid-prop-types
    props: PropTypes.object,
  }

  render() {
    const { props, ...rest } = this.props
    return (
      <Field
        {...rest}
        props={{
          ...props,
        }}
        type="checkbox"
        component={CheckboxField}
      />
    )
  }
}

export default OrderCheckboxField
